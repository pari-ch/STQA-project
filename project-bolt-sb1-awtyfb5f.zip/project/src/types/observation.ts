export type ObservationSource = 'real' | 'sample';

export interface Observation {
  id: string;
  image: string;
  latitude: number;
  longitude: number;
  timestamp: string;
  azimuth: number;
  elevation: number;
  fieldOfView: number;
  description: string;
  source: ObservationSource;
  createdAt: string;
}

export type ObservationInput = Omit<Observation, 'id' | 'createdAt'>;

export type Page = 'home' | 'capture' | 'map' | 'explorer' | 'dashboard' | 'about';

export interface GeoLocation {
  latitude: number;
  longitude: number;
  accuracy: number;
}

export interface DeviceOrientation {
  azimuth: number | null;
  elevation: number | null;
}
