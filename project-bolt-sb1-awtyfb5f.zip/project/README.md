# SkyTrace — Crowdsourced Sky Mapping

SkyTrace is a prototype for a crowdsourced sky-observation network. Users capture photographs of the sky from their location, and the app records GPS coordinates, camera direction (azimuth), elevation, field of view, and timestamp. Observations are displayed on an interactive world map and in a 2D "Sky Explorer" projection that places photos by azimuth and elevation — a first step toward a shared visual atlas of the sky.

## What It Does

- **Capture** — Take or upload a sky photo; the app reads GPS and device-orientation sensors (with manual fallback for desktop or unsupported browsers), then stores the full observation metadata.
- **Sky Map** — An interactive Leaflet world map showing all observation markers with popups and filters (source, direction, date).
- **Sky Explorer** — A 2D prototype sky projection that places photos by azimuth (horizontal) and elevation (vertical), labeled clearly as "Prototype Sky Reconstruction."
- **Dashboard** — Analytics including total observations, locations, continents, observations over time, and breakdown by continent and source.
- **Image Analysis** — Basic client-side pixel analysis (brightness, dark/bright pixel percentages, average color) labeled as experimental.
- **Observation Detail** — Full metadata view with photo, coordinates, direction, elevation, field of view, timestamp, and a "View in Sky Explorer" link.

## Technologies

- **React 18** + **TypeScript** — UI framework with strict typing
- **Vite** — Build tool and dev server
- **Tailwind CSS** — Styling with a custom dark astronomy theme
- **Leaflet** — Interactive maps (CARTO dark tiles)
- **Browser APIs** — Geolocation, DeviceOrientation, File/Camera input, Canvas (image analysis)
- **localStorage** — Client-side persistence (designed to be swapped for a cloud backend)

## Running the Project

```bash
npm install
npm run dev      # start dev server
npm run build    # production build
npm run typecheck # type checking
```

## Architecture

```
src/
├── types/           # TypeScript interfaces (Observation, GeoLocation, etc.)
├── services/        # Data layer
│   ├── storage.ts       # localStorage CRUD + pub/sub (swappable backend)
│   ├── observations.ts  # Merges user + sample data, re-exports API
│   ├── sampleData.ts    # 22 realistic demo observations
│   └── imageAnalysis.ts # Canvas-based pixel analysis
├── hooks/           # React hooks
│   ├── useObservations.ts      # Reactive observation list
│   ├── useGeolocation.ts       # GPS with error handling
│   └── useDeviceOrientation.ts # Compass/orientation with iOS permission
├── components/      # Reusable UI
│   ├── NavBar.tsx, Starfield.tsx, GlassCard.tsx
│   ├── ObservationDetail.tsx, ImageAnalysisCard.tsx
│   └── BarChart.tsx, DonutChart.tsx
├── pages/           # Page-level views
│   ├── HomePage.tsx, CapturePage.tsx, SkyMapPage.tsx
│   ├── SkyExplorerPage.tsx, DashboardPage.tsx, AboutPage.tsx
└── lib/             # Utilities (formatting, continent lookup)
```

## Connecting a Real Backend

The data layer is isolated behind `src/services/observations.ts` and `src/services/storage.ts`. To migrate to Firebase or Supabase:

1. Replace the functions in `storage.ts` (`getAllObservations`, `addObservation`, `deleteObservation`) with database calls.
2. Keep the `subscribe` pattern for realtime updates (Supabase realtime channels or Firebase `onSnapshot`).
3. The `Observation` interface in `src/types/observation.ts` maps directly to a table/collection schema.
4. No page or component changes are needed — they all consume the `useObservations` hook.

## Current Limitations

- Data is stored in localStorage (per-browser, not shared across devices or users)
- Device orientation accuracy varies by browser/device (iOS requires explicit permission)
- Sky Explorer is a 2D projection, not a true 3D celestial sphere
- Image analysis is basic pixel-level, not a trained ML model
- No celestial coordinate transformation (RA/Dec) yet
- Sample observations use stock sky photography, not real user-submitted photos

## Future Roadmap

- AI star and constellation detection
- Cloud and sky-condition classification
- Light pollution estimation (Bortle scale)
- Meteor and satellite trail detection
- Accurate azimuth/elevation → RA/Dec transformation
- Global-scale sky reconstruction
- Firebase/Supabase backend with realtime sync
- User accounts and observation history
- Real-time collaboration
