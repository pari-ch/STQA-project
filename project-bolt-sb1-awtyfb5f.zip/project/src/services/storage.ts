import type { Observation, ObservationInput } from '@/types/observation';

const STORAGE_KEY = 'skytrace_observations';

type Listener = () => void;
const listeners = new Set<Listener>();

function notify() {
  listeners.forEach((l) => l());
}

export function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function readAll(): Observation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Observation[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAll(obs: Observation[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(obs));
    notify();
  } catch (e) {
    console.error('Failed to persist observations:', e);
  }
}

export function getAllObservations(): Observation[] {
  return readAll();
}

export function getObservationById(id: string): Observation | null {
  return readAll().find((o) => o.id === id) ?? null;
}

export function addObservation(input: ObservationInput): Observation {
  const obs: Observation = {
    ...input,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };
  const all = readAll();
  writeAll([obs, ...all]);
  return obs;
}

export function deleteObservation(id: string): void {
  const all = readAll().filter((o) => o.id !== id);
  writeAll(all);
}

export function clearUserObservations(): void {
  const all = readAll().filter((o) => o.source === 'sample');
  writeAll(all);
}
