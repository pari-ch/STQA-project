/*
# Create celestial_objects table (single-tenant, no auth)

1. New Tables
- `celestial_objects`
  - `id` (uuid, primary key)
  - `name` (text, not null) — the star/phenomenon name
  - `constellation` (text, not null) — constellation the object belongs to
  - `right_ascension` (double precision, not null) — RA coordinate in hours (0–24)
  - `declination` (double precision, not null) — Dec coordinate in degrees (-90 to 90)
  - `apparent_magnitude` (double precision, not null) — brightness magnitude
  - `discovered_at` (timestamptz, default now()) — when the entry was logged
2. Seed Data
- Inserts starter rows: Sirius, Betelgeuse, Rigel, Vega, Polaris, Antares.
3. Security
- Enable RLS on `celestial_objects`.
- Allow anon + authenticated CRUD because the data is intentionally shared/public (no sign-in screen).
*/

CREATE TABLE IF NOT EXISTS celestial_objects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  constellation text NOT NULL,
  right_ascension double precision NOT NULL,
  declination double precision NOT NULL,
  apparent_magnitude double precision NOT NULL,
  discovered_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE celestial_objects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_celestial_objects" ON celestial_objects;
CREATE POLICY "anon_select_celestial_objects" ON celestial_objects FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_celestial_objects" ON celestial_objects;
CREATE POLICY "anon_insert_celestial_objects" ON celestial_objects FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_celestial_objects" ON celestial_objects;
CREATE POLICY "anon_update_celestial_objects" ON celestial_objects FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_celestial_objects" ON celestial_objects;
CREATE POLICY "anon_delete_celestial_objects" ON celestial_objects FOR DELETE
  TO anon, authenticated USING (true);

-- Seed starter data (only if table is empty)
INSERT INTO celestial_objects (name, constellation, right_ascension, declination, apparent_magnitude)
SELECT * FROM (VALUES
  ('Sirius',      'Canis Major',    6.7525,  -16.7161, -1.46),
  ('Betelgeuse',  'Orion',          5.9195,    7.4071,  0.42),
  ('Rigel',       'Orion',          5.2423,   -8.2016,  0.13),
  ('Vega',        'Lyra',          18.6156,   38.7837,  0.03),
  ('Polaris',     'Ursa Minor',     2.5302,   89.2641,  1.98),
  ('Antares',     'Scorpius',      16.4901,  -26.4320,  1.06)
) AS v(name, constellation, right_ascension, declination, apparent_magnitude)
WHERE NOT EXISTS (SELECT 1 FROM celestial_objects);
