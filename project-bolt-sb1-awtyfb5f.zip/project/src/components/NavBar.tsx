import { useState } from 'react';
import { Menu, X, Telescope } from 'lucide-react';
import type { Page } from '@/types/observation';

type Props = {
  current: Page;
  onNavigate: (page: Page) => void;
};

const NAV_ITEMS: { key: Page; label: string }[] = [
  { key: 'home', label: 'Home' },
  { key: 'capture', label: 'Capture' },
  { key: 'map', label: 'Sky Map' },
  { key: 'explorer', label: 'Sky Explorer' },
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'about', label: 'About' },
];

const MOBILE_ITEMS: { key: Page; label: string; icon: typeof Menu }[] = [
  { key: 'home', label: 'Home', icon: Menu },
  { key: 'capture', label: 'Capture', icon: Menu },
  { key: 'map', label: 'Map', icon: Menu },
  { key: 'explorer', label: 'Sky', icon: Menu },
  { key: 'dashboard', label: 'Stats', icon: Menu },
];

export default function NavBar({ current, onNavigate }: Props) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const go = (page: Page) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-50">
        <div className="glass-card border-x-0 border-t-0 border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
            <button onClick={() => go('home')} className="flex items-center gap-2.5 group">
              <span className="relative">
                <Telescope size={24} className="text-nebula-blue transition-transform duration-500 group-hover:rotate-12" />
                <span className="absolute inset-0 blur-md bg-nebula-blue/30 rounded-full" />
              </span>
              <span className="font-display text-lg font-bold tracking-wide text-starlight-100">
                Sky<span className="text-nebula-blue">Trace</span>
              </span>
            </button>

            <nav className="hidden lg:flex items-center gap-1">
              {NAV_ITEMS.map((item) => {
                const active = current === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => go(item.key)}
                    className={`relative px-4 py-2 rounded-lg text-sm font-medium tracking-wide transition-all duration-300 ${
                      active ? 'text-white' : 'text-starlight-300 hover:text-starlight-100'
                    }`}
                  >
                    {item.label}
                    {active && (
                      <span className="absolute -bottom-px left-1/2 -translate-x-1/2 h-px w-3/4 bg-gradient-to-r from-transparent via-nebula-blue to-transparent" />
                    )}
                  </button>
                );
              })}
            </nav>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 text-starlight-300 hover:text-white transition-colors"
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>

          {mobileOpen && (
            <nav className="lg:hidden border-t border-starlight-400/10 bg-sky-900/80 backdrop-blur-md animate-fadeIn">
              <div className="max-w-7xl mx-auto px-4 py-2 flex flex-col">
                {NAV_ITEMS.map((item) => {
                  const active = current === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => go(item.key)}
                      className={`text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                        active ? 'text-white bg-nebula-blue/15' : 'text-starlight-300 hover:text-starlight-100 hover:bg-sky-800/50'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </nav>
          )}
        </div>
      </header>

      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 glass-card border-x-0 border-b-0 border-t">
        <div className="flex items-center justify-around px-2 py-1.5">
          {MOBILE_ITEMS.map((item) => {
            const active = current === item.key;
            return (
              <button
                key={item.key}
                onClick={() => go(item.key)}
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-[10px] font-medium transition-colors ${
                  active ? 'text-nebula-blue' : 'text-starlight-400'
                }`}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
