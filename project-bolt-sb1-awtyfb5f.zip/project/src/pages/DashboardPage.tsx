import { useMemo } from 'react';
import { Camera, MapPin, Globe, Clock, TrendingUp } from 'lucide-react';
import type { Observation } from '@/types/observation';
import { getContinent, formatDateTime } from '@/lib/format';
import GlassCard from '@/components/GlassCard';
import BarChart from '@/components/BarChart';
import DonutChart from '@/components/DonutChart';

type Props = {
  observations: Observation[];
};

const CONTINENT_COLORS: Record<string, string> = {
  'Asia': '#3b82f6',
  'Europe': '#8b5cf6',
  'Africa': '#22d3ee',
  'North America': '#6366f1',
  'South America': '#ec4899',
  'Oceania': '#14b8a6',
  'Antarctica': '#94a3b8',
  'Other': '#64748b',
};

export default function DashboardPage({ observations }: Props) {
  const stats = useMemo(() => {
    const locations = new Set(observations.map((o) => `${o.latitude.toFixed(2)},${o.longitude.toFixed(2)}`));
    const continents = new Set(observations.map((o) => getContinent(o.latitude, o.longitude)));

    const byContinent: Record<string, number> = {};
    observations.forEach((o) => {
      const c = getContinent(o.latitude, o.longitude);
      byContinent[c] = (byContinent[c] || 0) + 1;
    });

    const last7Days: Record<string, number> = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const label = d.toLocaleDateString(undefined, { weekday: 'short' });
      last7Days[label] = 0;
    }
    observations.forEach((o) => {
      const diff = (Date.now() - new Date(o.createdAt).getTime()) / 86400000;
      if (diff <= 7) {
        const d = new Date(o.createdAt);
        const label = d.toLocaleDateString(undefined, { weekday: 'short' });
        if (label in last7Days) last7Days[label]++;
      }
    });

    const bySource = {
      real: observations.filter((o) => o.source === 'real').length,
      sample: observations.filter((o) => o.source === 'sample').length,
    };

    const recent = observations[0];

    return {
      total: observations.length,
      locations: locations.size,
      continents: continents.size,
      byContinent,
      last7Days,
      bySource,
      recent,
    };
  }, [observations]);

  const continentData = Object.entries(stats.byContinent)
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value);

  const timelineData = Object.entries(stats.last7Days).map(([label, value]) => ({ label, value }));

  const donutData = [
    { label: 'User', value: stats.bySource.real, color: '#22d3ee' },
    { label: 'Demo', value: stats.bySource.sample, color: '#8b5cf6' },
  ];

  const cards = [
    { label: 'Total Observations', value: stats.total, icon: Camera, color: 'text-nebula-blue' },
    { label: 'Locations', value: stats.locations, icon: MapPin, color: 'text-nebula-cyan' },
    { label: 'Continents', value: stats.continents, icon: Globe, color: 'text-nebula-purple' },
    { label: 'Most Recent', value: stats.recent ? formatDateTime(stats.recent.createdAt).split(',')[0] : '—', icon: Clock, color: 'text-nebula-indigo' },
  ];

  return (
    <div className="animate-fadeIn px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <p className="text-xs uppercase tracking-[0.3em] text-nebula-blue mb-2">Dashboard</p>
          <h2 className="font-display text-3xl font-bold text-starlight-100">Observation Analytics</h2>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {cards.map((card, i) => (
            <GlassCard key={i} hover className="p-5 animate-slideUp" >
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-sky-800/60 border border-starlight-400/10 mb-3">
                <card.icon size={18} className={card.color} />
              </div>
              <p className="font-display text-3xl font-bold text-starlight-100">{card.value}</p>
              <p className="text-xs uppercase tracking-wider text-starlight-400 mt-1">{card.label}</p>
            </GlassCard>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-5 mb-6">
          {/* Observations over time */}
          <GlassCard className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp size={18} className="text-nebula-cyan" />
              <h3 className="font-medium text-starlight-100">Observations — Last 7 Days</h3>
            </div>
            <BarChart data={timelineData} color="#3b82f6" height={200} />
          </GlassCard>

          {/* Source breakdown */}
          <GlassCard className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Camera size={18} className="text-nebula-cyan" />
              <h3 className="font-medium text-starlight-100">Observation Sources</h3>
            </div>
            <div className="flex items-center justify-center py-4">
              <DonutChart data={donutData} />
            </div>
          </GlassCard>
        </div>

        {/* By continent */}
        <GlassCard className="p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Globe size={18} className="text-nebula-cyan" />
            <h3 className="font-medium text-starlight-100">Observations by Continent</h3>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {continentData.map((c) => (
              <div key={c.label} className="flex items-center justify-between rounded-lg bg-sky-900/40 border border-starlight-400/10 px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: CONTINENT_COLORS[c.label] || '#64748b' }} />
                  <span className="text-sm text-starlight-200">{c.label}</span>
                </div>
                <span className="font-mono text-lg font-medium text-starlight-100">{c.value}</span>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Recent observation */}
        {stats.recent && (
          <GlassCard className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Clock size={18} className="text-nebula-cyan" />
              <h3 className="font-medium text-starlight-100">Most Recent Observation</h3>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <img src={stats.recent.image} alt="" className="w-full sm:w-48 h-32 object-cover rounded-xl border border-starlight-400/10" />
              <div className="flex-1 space-y-2">
                <p className="text-sm text-starlight-100">{stats.recent.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div><span className="text-starlight-400">Location: </span><span className="font-mono text-starlight-200">{stats.recent.latitude.toFixed(2)}, {stats.recent.longitude.toFixed(2)}</span></div>
                  <div><span className="text-starlight-400">When: </span><span className="font-mono text-starlight-200">{formatDateTime(stats.recent.timestamp)}</span></div>
                  <div><span className="text-starlight-400">Azimuth: </span><span className="font-mono text-starlight-200">{stats.recent.azimuth}°</span></div>
                  <div><span className="text-starlight-400">Elevation: </span><span className="font-mono text-starlight-200">{stats.recent.elevation}°</span></div>
                </div>
                <span className={`inline-block text-[10px] uppercase tracking-wider px-2 py-1 rounded-full ${stats.recent.source === 'sample' ? 'bg-nebula-purple/20 text-nebula-purple' : 'bg-emerald-400/15 text-emerald-300'}`}>
                  {stats.recent.source === 'sample' ? 'Demo' : 'User'}
                </span>
              </div>
            </div>
          </GlassCard>
        )}
      </div>
    </div>
  );
}
