import { useState, useCallback } from 'react';
import type { GeoLocation } from '@/types/observation';

type GeoState = {
  location: GeoLocation | null;
  loading: boolean;
  error: string | null;
  supported: boolean;
};

export function useGeolocation() {
  const [state, setState] = useState<GeoState>({
    location: null,
    loading: false,
    error: null,
    supported: typeof navigator !== 'undefined' && 'geolocation' in navigator,
  });

  const request = useCallback(() => {
    if (!navigator.geolocation) {
      setState((s) => ({ ...s, error: 'Geolocation not supported by this browser.', supported: false }));
      return;
    }
    setState((s) => ({ ...s, loading: true, error: null }));
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setState({
          location: {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
          },
          loading: false,
          error: null,
          supported: true,
        });
      },
      (err) => {
        let msg = 'Unable to retrieve location.';
        if (err.code === err.PERMISSION_DENIED) msg = 'Location permission denied. Enter coordinates manually.';
        else if (err.code === err.POSITION_UNAVAILABLE) msg = 'Position unavailable. Enter coordinates manually.';
        else if (err.code === err.TIMEOUT) msg = 'Location request timed out. Enter coordinates manually.';
        setState((s) => ({ ...s, loading: false, error: msg }));
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  }, []);

  return { ...state, request };
}
