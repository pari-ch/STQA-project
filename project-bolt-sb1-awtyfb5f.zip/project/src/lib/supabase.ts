import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type CelestialObject = {
  id: string;
  name: string;
  constellation: string;
  right_ascension: number;
  declination: number;
  apparent_magnitude: number;
  discovered_at: string;
};

export type CelestialInsert = {
  name: string;
  constellation: string;
  right_ascension: number;
  declination: number;
  apparent_magnitude: number;
};
