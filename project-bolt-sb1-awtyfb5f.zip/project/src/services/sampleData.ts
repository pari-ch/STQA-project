import type { Observation } from '@/types/observation';

const SKY_IMAGES = [
  'https://images.pexels.com/photos/28842660/pexels-photo-28842660.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/18358576/pexels-photo-18358576.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/39018962/pexels-photo-39018962.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/1341279/pexels-photo-1341279.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/3083808/pexels-photo-3083808.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/30648194/pexels-photo-30648194.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/7119/night-clouds-trees-milky-way.jpg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/31021507/pexels-photo-31021507.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/10057346/pexels-photo-10057346.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/28357540/pexels-photo-28357540.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/17810090/pexels-photo-17810090.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/11858855/pexels-photo-11858855.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/982378/nature-milky-way-galaxy-stars-982378.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/13065041/pexels-photo-13065041.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/35403637/pexels-photo-35403637.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/27771822/pexels-photo-27771822.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
];

type SampleSpec = {
  city: string;
  country: string;
  lat: number;
  lng: number;
  azimuth: number;
  elevation: number;
  fov: number;
  daysAgo: number;
  desc: string;
};

const SAMPLES: SampleSpec[] = [
  { city: 'Goa', country: 'India', lat: 15.2993, lng: 74.1240, azimuth: 45, elevation: 30, fov: 60, daysAgo: 2, desc: 'Clear Milky Way view over the Arabian Sea coast.' },
  { city: 'Goa', country: 'India', lat: 15.4909, lng: 73.7848, azimuth: 180, elevation: 15, fov: 50, daysAgo: 5, desc: 'Southern horizon — Scorpius rising above palm silhouettes.' },
  { city: 'Mumbai', country: 'India', lat: 19.0760, lng: 72.8777, azimuth: 270, elevation: 45, fov: 55, daysAgo: 1, desc: 'Western sky with urban light dome on the horizon.' },
  { city: 'Mumbai', country: 'India', lat: 19.1136, lng: 72.8697, azimuth: 0, elevation: 60, fov: 45, daysAgo: 7, desc: 'Polaris region captured from a rooftop observatory.' },
  { city: 'Delhi', country: 'India', lat: 28.6139, lng: 77.2090, azimuth: 90, elevation: 20, fov: 65, daysAgo: 3, desc: 'Eastern horizon before dawn — planets visible.' },
  { city: 'Delhi', country: 'India', lat: 28.5355, lng: 77.3910, azimuth: 135, elevation: 35, fov: 50, daysAgo: 10, desc: 'Summer triangle high in the southeast.' },
  { city: 'Bengaluru', country: 'India', lat: 12.9716, lng: 77.5946, azimuth: 200, elevation: 25, fov: 55, daysAgo: 4, desc: 'Sagittarius region with dense Milky Way star fields.' },
  { city: 'Bengaluru', country: 'India', lat: 12.9352, lng: 77.6245, azimuth: 315, elevation: 50, fov: 40, daysAgo: 8, desc: 'Northwestern sky — Andromeda region visible.' },
  { city: 'New York', country: 'USA', lat: 40.7128, lng: -74.0060, azimuth: 0, elevation: 40, fov: 60, daysAgo: 1, desc: 'Northern sky from Central Park — Big Dipper prominent.' },
  { city: 'New York', country: 'USA', lat: 40.6782, lng: -73.9442, azimuth: 120, elevation: 55, fov: 45, daysAgo: 6, desc: 'Summer Milky Way from Brooklyn rooftop.' },
  { city: 'London', country: 'UK', lat: 51.5074, lng: -0.1278, azimuth: 50, elevation: 35, fov: 50, daysAgo: 2, desc: 'Northeastern sky — Cassiopeia clearly visible.' },
  { city: 'London', country: 'UK', lat: 51.4934, lng: -0.0098, azimuth: 220, elevation: 20, fov: 55, daysAgo: 12, desc: 'Southern horizon from Greenwich — limited by light pollution.' },
  { city: 'Tokyo', country: 'Japan', lat: 35.6762, lng: 139.6503, azimuth: 180, elevation: 45, fov: 50, daysAgo: 3, desc: 'Southern sky from a Tokyo suburb — Scorpius region.' },
  { city: 'Tokyo', country: 'Japan', lat: 35.6586, lng: 139.7454, azimuth: 270, elevation: 30, fov: 60, daysAgo: 9, desc: 'Western sky at dusk from Tokyo Tower area.' },
  { city: 'Sydney', country: 'Australia', lat: -33.8688, lng: 151.2093, azimuth: 160, elevation: 50, fov: 55, daysAgo: 2, desc: 'Southern Cross and Pointers clearly visible.' },
  { city: 'Sydney', country: 'Australia', lat: -33.9173, lng: 151.2314, azimuth: 200, elevation: 25, fov: 45, daysAgo: 5, desc: 'Magellanic Clouds above the southern horizon.' },
  { city: 'Dubai', country: 'UAE', lat: 25.2048, lng: 55.2708, azimuth: 100, elevation: 40, fov: 60, daysAgo: 4, desc: 'Desert sky — exceptionally dark conditions near the city.' },
  { city: 'Dubai', country: 'UAE', lat: 25.0657, lng: 55.1713, azimuth: 350, elevation: 55, fov: 50, daysAgo: 11, desc: 'Northern sky from desert dunes — Polaris low on horizon.' },
  { city: 'Singapore', country: 'Singapore', lat: 1.3521, lng: 103.8198, azimuth: 175, elevation: 15, fov: 65, daysAgo: 1, desc: 'Equatorial southern horizon — Jupiter near the horizon.' },
  { city: 'Singapore', country: 'Singapore', lat: 1.2644, lng: 103.8220, azimuth: 40, elevation: 60, fov: 45, daysAgo: 6, desc: 'Tropical sky from Sentosa — Orion visible near zenith.' },
  { city: 'Reykjavik', country: 'Iceland', lat: 64.1466, lng: -21.9426, azimuth: 30, elevation: 35, fov: 55, daysAgo: 3, desc: 'Aurora and starry sky — subarctic winter night.' },
  { city: 'Cape Town', country: 'South Africa', lat: -33.9249, lng: 18.4241, azimuth: 210, elevation: 45, fov: 50, daysAgo: 7, desc: 'Southern Milky Way over Table Mountain.' },
];

export function getSampleObservations(): Observation[] {
  return SAMPLES.map((s, i) => {
    const ts = new Date(Date.now() - s.daysAgo * 86400000 - i * 3600000);
    return {
      id: `sample-${i + 1}`,
      image: SKY_IMAGES[i % SKY_IMAGES.length],
      latitude: s.lat,
      longitude: s.lng,
      timestamp: ts.toISOString(),
      azimuth: s.azimuth,
      elevation: s.elevation,
      fieldOfView: s.fov,
      description: s.desc,
      source: 'sample' as const,
      createdAt: ts.toISOString(),
    };
  });
}
