import { useEffect, useState } from 'react';
import { X, MapPin, Compass, Gauge, Camera, Calendar, FileText, Eye, Image as ImageIcon, Navigation, ArrowRight } from 'lucide-react';
import type { Page, Observation } from '@/types/observation';
import { formatCoord, formatDateTime, azimuthToCompass } from '@/lib/format';
import GlassCard from './GlassCard';
import ImageAnalysisCard from './ImageAnalysisCard';

type Props = {
  observation: Observation | null;
  onClose: () => void;
  onViewInExplorer?: (obs: Observation) => void;
  onNavigate?: (page: Page) => void;
};

export default function ObservationDetail({ observation, onClose, onViewInExplorer, onNavigate }: Props) {
  const [analysisOpen, setAnalysisOpen] = useState(false);

  useEffect(() => {
    if (observation) setAnalysisOpen(false);
  }, [observation]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  if (!observation) return null;

  const isSample = observation.source === 'sample';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-fadeIn">
      <div className="absolute inset-0 bg-sky-950/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto glass-card rounded-2xl border-nebula-blue/20">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-lg bg-sky-900/80 text-starlight-300 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>

        <div className="relative h-64 sm:h-80 overflow-hidden rounded-t-2xl">
          <img src={observation.image} alt={observation.description} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-sky-950 via-sky-950/20 to-transparent" />
          <div className="absolute bottom-4 left-4 flex items-center gap-2">
            <span className={`text-[10px] uppercase tracking-wider px-3 py-1 rounded-full font-medium ${
              isSample
                ? 'bg-nebula-purple/20 border border-nebula-purple/40 text-nebula-purple'
                : 'bg-emerald-400/15 border border-emerald-400/40 text-emerald-300'
            }`}>
              {isSample ? 'Demo Observation' : 'User Observation'}
            </span>
          </div>
        </div>

        <div className="p-6 space-y-5">
          <div>
            <h2 className="font-display text-2xl font-semibold text-starlight-100">Observation Detail</h2>
            <p className="text-xs text-starlight-400 mt-1 font-mono">ID: {observation.id}</p>
          </div>

          {observation.description && (
            <p className="text-sm text-starlight-200 italic">"{observation.description}"</p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <DetailRow icon={MapPin} label="Location" value={`${formatCoord(observation.latitude, 'lat')}, ${formatCoord(observation.longitude, 'lng')}`} />
            <DetailRow icon={Calendar} label="Date & Time" value={formatDateTime(observation.timestamp)} />
            <DetailRow icon={Compass} label="Azimuth" value={`${observation.azimuth}° (${azimuthToCompass(observation.azimuth)})`} />
            <DetailRow icon={Gauge} label="Elevation" value={`${observation.elevation}°`} />
            <DetailRow icon={Eye} label="Field of View" value={`${observation.fieldOfView}°`} />
            <DetailRow icon={Navigation} label="Source" value={isSample ? 'Demo' : 'User'} />
          </div>

          <div className="border-t border-starlight-400/10 pt-4">
            <button
              onClick={() => setAnalysisOpen(!analysisOpen)}
              className="w-full flex items-center justify-between text-sm font-medium text-starlight-200 hover:text-white transition-colors"
            >
              <span className="flex items-center gap-2">
                <ImageIcon size={16} className="text-nebula-cyan" />
                Basic Sky Analysis
              </span>
              <span className="text-xs text-starlight-400">{analysisOpen ? 'Hide' : 'Show'}</span>
            </button>
            {analysisOpen && (
              <div className="mt-4">
                <ImageAnalysisCard imageSrc={observation.image} />
              </div>
            )}
          </div>

          {onViewInExplorer && onNavigate && (
            <button
              onClick={() => {
                onViewInExplorer(observation);
                onNavigate('explorer');
                onClose();
              }}
              className="w-full flex items-center justify-center gap-2 rounded-xl border border-nebula-blue/30 bg-nebula-blue/10 px-6 py-3 font-medium text-nebula-cyan hover:bg-nebula-blue/20 transition-all duration-300"
            >
              View in Sky Explorer
              <ArrowRight size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function DetailRow({ icon: Icon, label, value }: { icon: typeof MapPin; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-sky-800/60 border border-starlight-400/10 flex items-center justify-center">
        <Icon size={15} className="text-nebula-cyan" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-starlight-400">{label}</p>
        <p className="text-sm text-starlight-100 font-mono break-words">{value}</p>
      </div>
    </div>
  );
}
