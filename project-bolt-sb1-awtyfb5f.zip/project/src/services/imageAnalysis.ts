export interface AnalysisResult {
  width: number;
  height: number;
  averageBrightness: number;
  darkPixelPercent: number;
  brightPixelPercent: number;
  averageRed: number;
  averageGreen: number;
  averageBlue: number;
}

export async function analyzeImage(imageSrc: string): Promise<AnalysisResult> {
  const img = new Image();
  img.crossOrigin = 'anonymous';

  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('Could not load image for analysis.'));
    img.src = imageSrc;
  });

  const maxDim = 200;
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas context unavailable.');
  ctx.drawImage(img, 0, 0, w, h);

  const { data } = ctx.getImageData(0, 0, w, h);
  let totalBrightness = 0;
  let darkPixels = 0;
  let brightPixels = 0;
  let totalR = 0;
  let totalG = 0;
  let totalB = 0;
  const pixelCount = data.length / 4;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const brightness = (r + g + b) / 3;
    totalBrightness += brightness;
    totalR += r;
    totalG += g;
    totalB += b;
    if (brightness < 40) darkPixels++;
    if (brightness > 200) brightPixels++;
  }

  return {
    width: img.width,
    height: img.height,
    averageBrightness: Math.round((totalBrightness / pixelCount / 255) * 100),
    darkPixelPercent: Math.round((darkPixels / pixelCount) * 100),
    brightPixelPercent: Math.round((brightPixels / pixelCount) * 100),
    averageRed: Math.round(totalR / pixelCount),
    averageGreen: Math.round(totalG / pixelCount),
    averageBlue: Math.round(totalB / pixelCount),
  };
}
