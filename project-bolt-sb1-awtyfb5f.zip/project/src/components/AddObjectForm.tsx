import { useState } from 'react';
import { CheckCircle2, AlertCircle, Loader2, Sparkles } from 'lucide-react';
import { CONSTELLATIONS } from '@/lib/constellations';
import type { CelestialInsert } from '@/lib/supabase';

type Props = {
  onSubmit: (obj: CelestialInsert) => Promise<boolean>;
};

type FormData = {
  name: string;
  constellation: string;
  right_ascension: string;
  declination: string;
  apparent_magnitude: string;
};

type Errors = Partial<Record<keyof FormData, string>>;

const EMPTY: FormData = {
  name: '',
  constellation: '',
  right_ascension: '',
  declination: '',
  apparent_magnitude: '',
};

export default function AddObjectForm({ onSubmit }: Props) {
  const [form, setForm] = useState<FormData>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const update = (field: keyof FormData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
    if (success) setSuccess(false);
    if (submitError) setSubmitError(null);
  };

  const validate = (): Errors => {
    const next: Errors = {};

    if (!form.name.trim()) next.name = 'Object name is required.';
    else if (form.name.trim().length < 2)
      next.name = 'Name must be at least 2 characters.';

    if (!form.constellation) next.constellation = 'Please select a constellation.';

    const ra = parseFloat(form.right_ascension);
    if (form.right_ascension === '' || Number.isNaN(ra))
      next.right_ascension = 'Right ascension is required.';
    else if (ra < 0 || ra > 24)
      next.right_ascension = 'Right ascension must be between 0 and 24 hours.';

    const dec = parseFloat(form.declination);
    if (form.declination === '' || Number.isNaN(dec))
      next.declination = 'Declination is required.';
    else if (dec < -90 || dec > 90)
      next.declination = 'Declination must be between −90° and +90°.';

    const mag = parseFloat(form.apparent_magnitude);
    if (form.apparent_magnitude === '' || Number.isNaN(mag))
      next.apparent_magnitude = 'Apparent magnitude is required.';
    else if (mag < -30 || mag > 30)
      next.apparent_magnitude = 'Enter a realistic magnitude value.';

    return next;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const found = validate();
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    setSubmitError(null);
    const ok = await onSubmit({
      name: form.name.trim(),
      constellation: form.constellation,
      right_ascension: parseFloat(form.right_ascension),
      declination: parseFloat(form.declination),
      apparent_magnitude: parseFloat(form.apparent_magnitude),
    });
    setSubmitting(false);

    if (ok) {
      setForm(EMPTY);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 4000);
    } else {
      setSubmitError('Could not save the object. Please try again.');
    }
  };

  const fieldClass = (field: keyof FormData) =>
    `input-field ${errors[field] ? 'input-field-error' : ''}`;

  const renderError = (field: keyof FormData) =>
    errors[field] && (
      <p className="mt-1.5 flex items-center gap-1.5 text-xs text-red-400">
        <AlertCircle size={12} />
        {errors[field]}
      </p>
    );

  return (
    <div className="animate-fadeIn max-w-2xl mx-auto">
      <div className="flex flex-col gap-2 mb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-gold-500/80">
          New Entry
        </p>
        <h2 className="font-display text-4xl font-semibold text-silver-100 text-glow-gold">
          Add a Celestial Object
        </h2>
        <p className="text-silver-400 text-sm">
          Record a newly discovered star or sky phenomenon into the registry.
        </p>
      </div>

      {success && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 animate-fadeIn">
          <CheckCircle2 size={18} className="text-emerald-300" />
          <p className="text-sm text-emerald-200">
            Object recorded successfully. It now appears on the dashboard.
          </p>
        </div>
      )}
      {submitError && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-red-400/30 bg-red-400/10 px-4 py-3">
          <AlertCircle size={18} className="text-red-300" />
          <p className="text-sm text-red-200">{submitError}</p>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        noValidate
        className="glass-panel rounded-2xl p-6 sm:p-8 space-y-6"
      >
        <div>
          <label
            htmlFor="name"
            className="block text-sm font-medium text-silver-200 mb-2"
          >
            Object Name
          </label>
          <input
            id="name"
            type="text"
            value={form.name}
            onChange={(e) => update('name', e.target.value)}
            placeholder="e.g. Earendel"
            className={fieldClass('name')}
          />
          {renderError('name')}
        </div>

        <div>
          <label
            htmlFor="constellation"
            className="block text-sm font-medium text-silver-200 mb-2"
          >
            Constellation
          </label>
          <select
            id="constellation"
            value={form.constellation}
            onChange={(e) => update('constellation', e.target.value)}
            className={fieldClass('constellation')}
          >
            <option value="">Select a constellation…</option>
            {CONSTELLATIONS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          {renderError('constellation')}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label
              htmlFor="ra"
              className="block text-sm font-medium text-silver-200 mb-2"
            >
              Right Ascension{' '}
              <span className="text-silver-400 font-normal">(hours, 0–24)</span>
            </label>
            <input
              id="ra"
              type="number"
              step="any"
              value={form.right_ascension}
              onChange={(e) => update('right_ascension', e.target.value)}
              placeholder="6.7525"
              className={fieldClass('right_ascension')}
            />
            {renderError('right_ascension')}
          </div>

          <div>
            <label
              htmlFor="dec"
              className="block text-sm font-medium text-silver-200 mb-2"
            >
              Declination{' '}
              <span className="text-silver-400 font-normal">(°, −90 to +90)</span>
            </label>
            <input
              id="dec"
              type="number"
              step="any"
              value={form.declination}
              onChange={(e) => update('declination', e.target.value)}
              placeholder="-16.7161"
              className={fieldClass('declination')}
            />
            {renderError('declination')}
          </div>
        </div>

        <div>
          <label
            htmlFor="mag"
            className="block text-sm font-medium text-silver-200 mb-2"
          >
            Apparent Magnitude / Brightness
          </label>
          <input
            id="mag"
            type="number"
            step="any"
            value={form.apparent_magnitude}
            onChange={(e) => update('apparent_magnitude', e.target.value)}
            placeholder="-1.46"
            className={fieldClass('apparent_magnitude')}
          />
          {renderError('apparent_magnitude')}
          <p className="mt-1.5 text-xs text-silver-500">
            Lower values are brighter. Sirius is −1.46; the faintest naked-eye
            stars are around +6.
          </p>
        </div>

        <div className="pt-2">
          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-gold-600 to-gold-500 px-6 py-3.5 font-medium text-ink-950 tracking-wide transition-all duration-300 hover:from-gold-500 hover:to-gold-400 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-[0_0_30px_rgba(227,196,121,0.3)]"
          >
            {submitting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Recording…
              </>
            ) : (
              <>
                <Sparkles size={18} />
                Submit Entry
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
