import type { Observation, ObservationInput } from '@/types/observation';
import { getAllObservations, addObservation as addStored, deleteObservation as deleteStored, subscribe } from './storage';
import { getSampleObservations } from './sampleData';

export { subscribe };

export function getAll(): Observation[] {
  const user = getAllObservations();
  const samples = getSampleObservations();
  return [...user, ...samples].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function getById(id: string): Observation | null {
  return getAll().find((o) => o.id === id) ?? null;
}

export function add(input: ObservationInput): Observation {
  return addStored(input);
}

export function remove(id: string): void {
  deleteStored(id);
}
