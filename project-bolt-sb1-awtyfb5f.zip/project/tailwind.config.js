/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        sky: {
          950: '#03040a',
          900: '#070a18',
          850: '#0b1024',
          800: '#101838',
          700: '#182250',
          600: '#243068',
        },
        nebula: {
          blue: '#3b82f6',
          cyan: '#22d3ee',
          purple: '#8b5cf6',
          indigo: '#6366f1',
        },
        starlight: {
          100: '#f0f4ff',
          200: '#dde4f7',
          300: '#b8c4e0',
          400: '#8b99c2',
          500: '#5d6a96',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      keyframes: {
        twinkle: {
          '0%, 100%': { opacity: '0.15' },
          '50%': { opacity: '0.8' },
        },
        floatY: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(59,130,246,0.15)' },
          '50%': { boxShadow: '0 0 40px rgba(59,130,246,0.35)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      animation: {
        twinkle: 'twinkle 4s ease-in-out infinite',
        floatY: 'floatY 5s ease-in-out infinite',
        fadeIn: 'fadeIn 0.5s ease-out both',
        pulseGlow: 'pulseGlow 3s ease-in-out infinite',
        slideUp: 'slideUp 0.6s ease-out both',
        shimmer: 'shimmer 3s linear infinite',
      },
    },
  },
  plugins: [],
};
