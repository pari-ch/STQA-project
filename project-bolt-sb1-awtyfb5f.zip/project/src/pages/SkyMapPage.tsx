import { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import { Filter, Eye, MapPin } from 'lucide-react';
import type { Observation } from '@/types/observation';
import { formatDateTime, azimuthToCompass } from '@/lib/format';
import GlassCard from '@/components/GlassCard';
import ObservationDetail from '@/components/ObservationDetail';

type Props = {
  observations: Observation[];
};

type SourceFilter = 'all' | 'real' | 'sample';

function createIcon(source: string): L.DivIcon {
  const color = source === 'sample' ? '#8b5cf6' : '#22d3ee';
  return L.divIcon({
    className: 'skytrace-marker',
    html: `<div style="width:14px;height:14px;border-radius:50%;background:${color};border:2px solid rgba(255,255,255,0.4);box-shadow:0 0 12px ${color}80;"></div>`,
    iconSize: [14, 14],
    iconAnchor: [7, 7],
  });
}

export default function SkyMapPage({ observations }: Props) {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const [selected, setSelected] = useState<Observation | null>(null);

  const [sourceFilter, setSourceFilter] = useState<SourceFilter>('all');
  const [directionFilter, setDirectionFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');

  const filtered = useMemo(() => {
    return observations.filter((o) => {
      if (sourceFilter !== 'all' && o.source !== sourceFilter) return false;
      if (directionFilter !== 'all') {
        const sector = Math.floor(o.azimuth / 90);
        if (directionFilter === 'north' && sector !== 0) return false;
        if (directionFilter === 'east' && sector !== 1) return false;
        if (directionFilter === 'south' && sector !== 2) return false;
        if (directionFilter === 'west' && sector !== 3) return false;
      }
      if (dateFilter !== 'all') {
        const days = (Date.now() - new Date(o.timestamp).getTime()) / 86400000;
        if (dateFilter === 'today' && days > 1) return false;
        if (dateFilter === 'week' && days > 7) return false;
        if (dateFilter === 'month' && days > 30) return false;
      }
      return true;
    });
  }, [observations, sourceFilter, directionFilter, dateFilter]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, {
      center: [20, 0],
      zoom: 2,
      worldCopyJump: true,
      zoomControl: true,
    });
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO',
      maxZoom: 18,
    }).addTo(map);
    mapRef.current = map;
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    filtered.forEach((obs) => {
      const marker = L.marker([obs.latitude, obs.longitude], { icon: createIcon(obs.source) });
      marker.bindPopup(`
        <div style="width:200px;">
          <img src="${obs.image}" style="width:100%;height:100px;object-fit:cover;border-radius:8px;margin-bottom:8px;" />
          <p style="font-size:11px;color:#8b99c2;margin:0 0 4px;">${formatDateTime(obs.timestamp)}</p>
          <p style="font-size:12px;color:#dde4f7;margin:0 0 4px;">📍 ${obs.latitude.toFixed(2)}, ${obs.longitude.toFixed(2)}</p>
          <p style="font-size:12px;color:#dde4f7;margin:0 0 4px;">🧭 ${obs.azimuth}° ${azimuthToCompass(obs.azimuth)}</p>
          <p style="font-size:12px;color:#dde4f7;margin:0;">⬆ ${obs.elevation}° · ${obs.source === 'sample' ? 'Demo' : 'User'}</p>
        </div>
      `);
      marker.on('click', () => setSelected(obs));
      marker.addTo(map);
      markersRef.current.push(marker);
    });
  }, [filtered]);

  useEffect(() => {
    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  return (
    <div className="animate-fadeIn px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <p className="text-xs uppercase tracking-[0.3em] text-nebula-blue mb-2">Sky Map</p>
          <h2 className="font-display text-3xl font-bold text-starlight-100">Observations Around the World</h2>
        </div>

        <div className="grid lg:grid-cols-[1fr_280px] gap-5">
          <GlassCard className="overflow-hidden">
            <div ref={containerRef} className="w-full h-[500px] lg:h-[600px]" />
          </GlassCard>

          <div className="space-y-4">
            <GlassCard className="p-5">
              <div className="flex items-center gap-2 mb-4">
                <Filter size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">Filters</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="label-text">Source</label>
                  <select value={sourceFilter} onChange={(e) => setSourceFilter(e.target.value as SourceFilter)} className="input-field">
                    <option value="all">All Observations</option>
                    <option value="real">User Only</option>
                    <option value="sample">Demo Only</option>
                  </select>
                </div>

                <div>
                  <label className="label-text">Direction</label>
                  <select value={directionFilter} onChange={(e) => setDirectionFilter(e.target.value)} className="input-field">
                    <option value="all">All Directions</option>
                    <option value="north">North (0–90°)</option>
                    <option value="east">East (90–180°)</option>
                    <option value="south">South (180–270°)</option>
                    <option value="west">West (270–360°)</option>
                  </select>
                </div>

                <div>
                  <label className="label-text">Date</label>
                  <select value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} className="input-field">
                    <option value="all">All Time</option>
                    <option value="today">Last 24 hours</option>
                    <option value="week">Last 7 days</option>
                    <option value="month">Last 30 days</option>
                  </select>
                </div>
              </div>
            </GlassCard>

            <GlassCard className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <Eye size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">Display</h3>
              </div>
              <p className="font-display text-3xl font-bold text-starlight-100">{filtered.length}</p>
              <p className="text-xs text-starlight-400">of {observations.length} observations shown</p>
              <div className="flex items-center gap-4 mt-3 pt-3 border-t border-starlight-400/10">
                <Legend color="#22d3ee" label="User" count={filtered.filter((o) => o.source === 'real').length} />
                <Legend color="#8b5cf6" label="Demo" count={filtered.filter((o) => o.source === 'sample').length} />
              </div>
            </GlassCard>

            <GlassCard className="p-5 max-h-64 overflow-y-auto">
              <div className="flex items-center gap-2 mb-3">
                <MapPin size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">Observation List</h3>
              </div>
              <div className="space-y-2">
                {filtered.slice(0, 12).map((obs) => (
                  <button
                    key={obs.id}
                    onClick={() => setSelected(obs)}
                    className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-sky-800/40 transition-colors text-left"
                  >
                    <img src={obs.image} alt="" className="w-10 h-10 rounded object-cover flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-starlight-100 truncate">{obs.latitude.toFixed(2)}, {obs.longitude.toFixed(2)}</p>
                      <p className="text-[10px] text-starlight-400">{formatDateTime(obs.timestamp)}</p>
                    </div>
                    <span className={`w-2 h-2 rounded-full flex-shrink-0 ${obs.source === 'sample' ? 'bg-nebula-purple' : 'bg-nebula-cyan'}`} />
                  </button>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      </div>

      <ObservationDetail observation={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function Legend({ color, label, count }: { color: string; label: string; count: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
      <span className="text-xs text-starlight-300">{label} ({count})</span>
    </div>
  );
}
