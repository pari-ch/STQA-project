import { useMemo, useState, useRef, useEffect } from 'react';
import { Eye, Compass, Gauge, MapPin, Calendar, Layers, AlertTriangle, Grid3x3, Expand, Navigation } from 'lucide-react';
import type { Observation } from '@/types/observation';
import { formatCoord, azimuthToCompass } from '@/lib/format';
import GlassCard from '@/components/GlassCard';
import ObservationDetail from '@/components/ObservationDetail';

type Props = {
  observations: Observation[];
  focusId?: string | null;
};

type ViewMode = 'mosaic' | 'thumbnail';
type ElevRange = 'horizon' | 'all';

const COMPASS_DIRS = [
  { label: 'N', az: 0 },
  { label: 'NE', az: 45 },
  { label: 'E', az: 90 },
  { label: 'SE', az: 135 },
  { label: 'S', az: 180 },
  { label: 'SW', az: 225 },
  { label: 'W', az: 270 },
  { label: 'NW', az: 315 },
];

interface PlacedObs {
  obs: Observation;
  leftPct: number;
  topPct: number;
  widthPct: number;
  heightPct: number;
  zIndex: number;
  offsetIdx: number;
}

export default function SkyExplorerPage({ observations, focusId }: Props) {
  const [selected, setSelected] = useState<Observation | null>(null);
  const [locationFilter, setLocationFilter] = useState('all');
  const [timeFilter, setTimeFilter] = useState('all');
  const [viewMode, setViewMode] = useState<ViewMode>('mosaic');
  const [elevRange, setElevRange] = useState<ElevRange>('horizon');
  const [hovered, setHovered] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerSize, setContainerSize] = useState({ w: 800, h: 600 });

  useEffect(() => {
    if (!containerRef.current) return;
    const el = containerRef.current;
    const update = () => setContainerSize({ w: el.clientWidth, h: el.clientHeight });
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const locations = useMemo(() => {
    const map = new Map<string, { lat: number; lng: number; label: string }>();
    observations.forEach((o) => {
      const key = `${o.latitude.toFixed(1)},${o.longitude.toFixed(1)}`;
      if (!map.has(key)) {
        map.set(key, { lat: o.latitude, lng: o.longitude, label: `${formatCoord(o.latitude, 'lat')} ${formatCoord(o.longitude, 'lng')}` });
      }
    });
    return Array.from(map.values());
  }, [observations]);

  const filtered = useMemo(() => {
    return observations.filter((o) => {
      if (locationFilter !== 'all') {
        const key = `${o.latitude.toFixed(1)},${o.longitude.toFixed(1)}`;
        if (key !== locationFilter) return false;
      }
      if (timeFilter !== 'all') {
        const hour = new Date(o.timestamp).getHours();
        if (timeFilter === 'day' && (hour < 6 || hour > 18)) return false;
        if (timeFilter === 'night' && hour >= 6 && hour <= 18) return false;
      }
      if (elevRange === 'horizon' && o.elevation < 0) return false;
      return true;
    });
  }, [observations, locationFilter, timeFilter, elevRange]);

  const focusObs = focusId ? observations.find((o) => o.id === focusId) : null;

  // Place each photo by azimuth/elevation, sized by FOV, with overlap offsets.
  const placed: PlacedObs[] = useMemo(() => {
    const elevMin = elevRange === 'horizon' ? 0 : -90;
    const elevMax = 90;
    const elevSpan = elevMax - elevMin;

    // Sort by elevation descending so higher photos render first (behind).
    const sorted = [...filtered].sort((a, b) => b.elevation - a.elevation);

    // Track placed centers to detect overlaps and apply offsets.
    const placedCenters: { left: number; top: number; w: number; h: number }[] = [];

    return sorted.map((obs, idx) => {
      const leftPct = (obs.azimuth / 360) * 100;
      const topPct = ((elevMax - obs.elevation) / elevSpan) * 100;

      // FOV-based sizing: map FOV (degrees) to a percentage of the container.
      // A 60° FOV covers roughly 1/6 of the 360° panorama horizontally.
      const fovW = (obs.fieldOfView / 360) * 100;
      // Height: FOV maps onto the elevation span, but clamp so photos stay readable.
      const fovH = (obs.fieldOfView / elevSpan) * 100;

      // In thumbnail mode, use fixed small size.
      const widthPct = viewMode === 'mosaic' ? Math.max(6, Math.min(28, fovW)) : 8;
      const heightPct = viewMode === 'mosaic' ? Math.max(8, Math.min(30, fovH)) : 10;

      // Overlap detection: find how many already-placed photos overlap this one.
      let offsetIdx = 0;
      const myBox = { left: leftPct, top: topPct, w: widthPct, h: heightPct };
      for (const pc of placedCenters) {
        const dx = Math.abs(pc.left - myBox.left);
        const dy = Math.abs(pc.top - myBox.top);
        const overlapX = dx < (pc.w + myBox.w) / 2 * 0.7;
        const overlapY = dy < (pc.h + myBox.h) / 2 * 0.7;
        if (overlapX && overlapY) {
          offsetIdx++;
        }
      }
      placedCenters.push(myBox);

      return {
        obs,
        leftPct,
        topPct,
        widthPct,
        heightPct,
        zIndex: 10 + idx + offsetIdx * 5,
        offsetIdx,
      };
    });
  }, [filtered, viewMode, elevRange]);

  return (
    <div className="animate-fadeIn px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <p className="text-xs uppercase tracking-[0.3em] text-nebula-blue mb-2">Sky Explorer</p>
          <h2 className="font-display text-3xl font-bold text-starlight-100">Prototype Sky Reconstruction</h2>
          <div className="flex items-start gap-2 mt-3 max-w-2xl">
            <AlertTriangle size={14} className="text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-starlight-400">
              This is a 2D prototype visualization — not a scientifically accurate sky reconstruction.
              Photos are positioned by azimuth (horizontal) and elevation (vertical), sized by field of view.
              Where observations overlap, they are stacked with a slight offset.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-[1fr_260px] gap-5">
          {/* Sky projection */}
          <GlassCard className="overflow-hidden">
            <div
              ref={containerRef}
              className="relative bg-gradient-to-b from-sky-900 via-sky-950 to-black h-[500px] lg:h-[600px] overflow-hidden"
            >
              {/* Grid lines */}
              <div className="absolute inset-0 pointer-events-none">
                {[25, 50, 75].map((p) => (
                  <div key={`h-${p}`} className="absolute left-0 right-0 border-t border-starlight-400/5" style={{ top: `${p}%` }} />
                ))}
                {[12.5, 25, 37.5, 50, 62.5, 75, 87.5].map((p) => (
                  <div key={`v-${p}`} className="absolute top-0 bottom-0 border-l border-starlight-400/5" style={{ left: `${p}%` }} />
                ))}
              </div>

              {/* Horizon glow at bottom */}
              <div className="absolute bottom-0 left-0 right-0 h-1/4 bg-gradient-to-t from-nebula-blue/8 to-transparent pointer-events-none" />
              {/* Zenith glow at top */}
              <div className="absolute top-0 left-0 right-0 h-1/6 bg-gradient-to-b from-nebula-purple/5 to-transparent pointer-events-none" />

              {/* Compass labels along bottom */}
              <div className="absolute bottom-1 left-0 right-0 flex justify-between px-2 pointer-events-none">
                {COMPASS_DIRS.map((d) => (
                  <span key={d.label} className="text-[10px] font-mono text-starlight-400/60">
                    {d.label}
                  </span>
                ))}
              </div>

              {/* Elevation labels along left edge */}
              <div className="absolute left-1 top-0 bottom-6 flex flex-col justify-between pointer-events-none">
                {elevRange === 'horizon' ? (
                  <>
                    <span className="text-[10px] font-mono text-starlight-400/60">90°</span>
                    <span className="text-[10px] font-mono text-starlight-400/60">45°</span>
                    <span className="text-[10px] font-mono text-starlight-400/60">0°</span>
                  </>
                ) : (
                  <>
                    <span className="text-[10px] font-mono text-starlight-400/60">+90°</span>
                    <span className="text-[10px] font-mono text-starlight-400/60">0°</span>
                    <span className="text-[10px] font-mono text-starlight-400/60">-90°</span>
                  </>
                )}
              </div>

              {/* Azimuth axis label */}
              <div className="absolute top-1 left-1/2 -translate-x-1/2 pointer-events-none">
                <span className="text-[10px] font-mono text-starlight-400/40 uppercase tracking-widest">Azimuth →</span>
              </div>

              {/* Observation photos positioned by azimuth + elevation */}
              {placed.map(({ obs, leftPct, topPct, widthPct, heightPct, zIndex, offsetIdx }, i) => {
                const isFocus = focusObs?.id === obs.id;
                const isHovered = hovered === obs.id;
                const offsetX = (offsetIdx % 3) * 3;
                const offsetY = Math.floor(offsetIdx / 3) * 4;

                if (viewMode === 'mosaic') {
                  return (
                    <button
                      key={obs.id}
                      onClick={() => setSelected(obs)}
                      onMouseEnter={() => setHovered(obs.id)}
                      onMouseLeave={() => setHovered(null)}
                      className={`absolute group rounded-lg overflow-hidden border-2 transition-all duration-300 ${isFocus ? 'ring-2 ring-nebula-cyan z-30' : ''} ${isHovered ? 'z-40' : ''}`}
                      style={{
                        left: `calc(${leftPct}% + ${offsetX}%)`,
                        top: `calc(${topPct}% + ${offsetY}%)`,
                        width: `${widthPct}%`,
                        height: `${heightPct}%`,
                        transform: 'translate(-50%, -50%)',
                        zIndex: isHovered ? 40 : zIndex,
                        animation: 'fadeIn 0.5s ease-out both',
                        animationDelay: `${i * 30}ms`,
                        borderColor: obs.source === 'sample' ? 'rgba(139,92,246,0.25)' : 'rgba(34,211,238,0.25)',
                      }}
                    >
                      <img
                        src={obs.image}
                        alt={obs.description}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-sky-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
                      {offsetIdx > 0 && (
                        <span className="absolute top-0.5 right-0.5 text-[8px] font-mono px-1 rounded bg-sky-950/80 text-nebula-cyan">
                          +{offsetIdx}
                        </span>
                      )}
                      {/* Hover tooltip */}
                      {isHovered && (
                        <div className="absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-1 rounded bg-sky-950/95 border border-nebula-blue/30 text-[10px] text-starlight-100 pointer-events-none">
                          Az {obs.azimuth}° · El {obs.elevation}° · FOV {obs.fieldOfView}°
                        </div>
                      )}
                    </button>
                  );
                }

                // Thumbnail mode — fixed-size dots with FOV ring
                return (
                  <button
                    key={obs.id}
                    onClick={() => setSelected(obs)}
                    onMouseEnter={() => setHovered(obs.id)}
                    onMouseLeave={() => setHovered(null)}
                    className={`absolute group transition-all duration-300 ${isFocus ? 'z-30' : ''} ${isHovered ? 'z-40' : ''}`}
                    style={{
                      left: `calc(${leftPct}% + ${offsetX}%)`,
                      top: `calc(${topPct}% + ${offsetY}%)`,
                      transform: 'translate(-50%, -50%)',
                      zIndex: isHovered ? 40 : zIndex,
                      animation: 'fadeIn 0.5s ease-out both',
                      animationDelay: `${i * 30}ms`,
                    }}
                  >
                    {/* FOV ring */}
                    <div
                      className="absolute rounded-full border border-nebula-cyan/15"
                      style={{
                        width: `${Math.max(20, (obs.fieldOfView / 90) * 40)}px`,
                        height: `${Math.max(20, (obs.fieldOfView / 90) * 40)}px`,
                        left: '50%',
                        top: '50%',
                        transform: 'translate(-50%, -50%)',
                      }}
                    />
                    <img
                      src={obs.image}
                      alt={obs.description}
                      className={`relative w-12 h-12 rounded-full object-cover border-2 transition-all duration-300 ${
                        obs.source === 'sample' ? 'border-nebula-purple/40' : 'border-nebula-cyan/40'
                      } group-hover:scale-150 group-hover:border-nebula-cyan`}
                    />
                    {isHovered && (
                      <div className="absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-1 rounded bg-sky-950/95 border border-nebula-blue/30 text-[10px] text-starlight-100 pointer-events-none">
                        Az {obs.azimuth}° · El {obs.elevation}°
                      </div>
                    )}
                  </button>
                );
              })}

              {filtered.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-sm text-starlight-400">No observations match the current filters.</p>
                </div>
              )}
            </div>
          </GlassCard>

          {/* Controls */}
          <div className="space-y-4">
            <GlassCard className="p-5">
              <div className="flex items-center gap-2 mb-4">
                <Layers size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">Controls</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="label-text flex items-center gap-1.5"><MapPin size={12} /> Location</label>
                  <select value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)} className="input-field">
                    <option value="all">All Locations</option>
                    {locations.map((loc, i) => (
                      <option key={i} value={`${loc.lat.toFixed(1)},${loc.lng.toFixed(1)}`}>
                        {formatCoord(loc.lat, 'lat')} {formatCoord(loc.lng, 'lng')}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label-text flex items-center gap-1.5"><Calendar size={12} /> Time of Day</label>
                  <select value={timeFilter} onChange={(e) => setTimeFilter(e.target.value)} className="input-field">
                    <option value="all">Any Time</option>
                    <option value="day">Daytime</option>
                    <option value="night">Nighttime</option>
                  </select>
                </div>
                <div>
                  <label className="label-text flex items-center gap-1.5"><Navigation size={12} /> Elevation Range</label>
                  <select value={elevRange} onChange={(e) => setElevRange(e.target.value as ElevRange)} className="input-field">
                    <option value="horizon">Horizon to Zenith (0°–90°)</option>
                    <option value="all">Full Range (−90° to +90°)</option>
                  </select>
                </div>
              </div>
            </GlassCard>

            <GlassCard className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <Grid3x3 size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">View Mode</h3>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setViewMode('mosaic')}
                  className={`flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-all ${
                    viewMode === 'mosaic'
                      ? 'bg-nebula-blue/20 border border-nebula-blue/40 text-nebula-cyan'
                      : 'bg-sky-900/50 border border-starlight-400/10 text-starlight-400 hover:text-starlight-200'
                  }`}
                >
                  <Expand size={14} /> Mosaic
                </button>
                <button
                  onClick={() => setViewMode('thumbnail')}
                  className={`flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-all ${
                    viewMode === 'thumbnail'
                      ? 'bg-nebula-blue/20 border border-nebula-blue/40 text-nebula-cyan'
                      : 'bg-sky-900/50 border border-starlight-400/10 text-starlight-400 hover:text-starlight-200'
                  }`}
                >
                  <Grid3x3 size={14} /> Dots
                </button>
              </div>
              <p className="text-[10px] text-starlight-500 mt-2 leading-relaxed">
                {viewMode === 'mosaic'
                  ? 'Photos sized by field of view — wider FOV covers more sky.'
                  : 'Compact dots with FOV rings for a cleaner overview.'}
              </p>
            </GlassCard>

            <GlassCard className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <Eye size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">Display</h3>
              </div>
              <p className="font-display text-3xl font-bold text-starlight-100">{filtered.length}</p>
              <p className="text-xs text-starlight-400">photos positioned on sky dome</p>
            </GlassCard>

            {focusObs && (
              <GlassCard className="p-5 border-nebula-cyan/30">
                <p className="text-xs uppercase tracking-wider text-nebula-cyan mb-2">Focused Observation</p>
                <img src={focusObs.image} alt="" className="w-full h-24 rounded-lg object-cover mb-2" />
                <p className="text-xs text-starlight-200">{formatCoord(focusObs.latitude, 'lat')} {formatCoord(focusObs.longitude, 'lng')}</p>
                <p className="text-xs text-starlight-400 mt-1">Az {focusObs.azimuth}° · El {focusObs.elevation}° · FOV {focusObs.fieldOfView}°</p>
              </GlassCard>
            )}

            <GlassCard className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <Compass size={16} className="text-nebula-cyan" />
                <h3 className="font-medium text-starlight-100 text-sm">How to Read</h3>
              </div>
              <div className="space-y-2 text-xs text-starlight-400">
                <p className="flex items-center gap-2"><Compass size={12} /> Horizontal = azimuth (N→E→S→W)</p>
                <p className="flex items-center gap-2"><Gauge size={12} /> Vertical = elevation (0° horizon → 90° zenith)</p>
                <p className="flex items-center gap-2"><Expand size={12} /> Photo size = field of view coverage</p>
                <p className="flex items-center gap-2"><Layers size={12} /> Overlapping photos are stacked with offset</p>
                <p className="flex items-center gap-2"><Eye size={12} /> Click any photo for full details</p>
              </div>
            </GlassCard>
          </div>
        </div>
      </div>

      <ObservationDetail observation={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
