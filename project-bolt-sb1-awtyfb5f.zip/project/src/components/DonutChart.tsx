type PieSlice = { label: string; value: number; color: string };

type Props = {
  data: PieSlice[];
  size?: number;
};

export default function DonutChart({ data, size = 160 }: Props) {
  const total = data.reduce((sum, d) => sum + d.value, 0) || 1;
  const radius = size / 2;
  const stroke = size * 0.16;
  const inner = radius - stroke;
  const circumference = 2 * Math.PI * inner;
  let offset = 0;

  return (
    <div className="flex items-center gap-5">
      <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          {data.map((d, i) => {
            const fraction = d.value / total;
            const dash = fraction * circumference;
            const gap = circumference - dash;
            const el = (
              <circle
                key={i}
                cx={radius}
                cy={radius}
                r={inner}
                fill="none"
                stroke={d.color}
                strokeWidth={stroke}
                strokeDasharray={`${dash} ${gap}`}
                strokeDashoffset={-offset}
                strokeLinecap="round"
              />
            );
            offset += dash;
            return el;
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-display font-bold text-starlight-100">{total}</span>
          <span className="text-[10px] uppercase tracking-wider text-starlight-400">Total</span>
        </div>
      </div>
      <div className="space-y-1.5">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2 text-sm">
            <span className="w-3 h-3 rounded-sm" style={{ backgroundColor: d.color }} />
            <span className="text-starlight-300">{d.label}</span>
            <span className="text-starlight-100 font-mono ml-auto">{d.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
