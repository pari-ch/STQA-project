import { Star, Compass, Telescope, Ruler } from 'lucide-react';
import type { CelestialObject } from '@/lib/supabase';

type Props = {
  objects: CelestialObject[];
  loading: boolean;
};

function formatRA(ra: number): string {
  const h = Math.floor(ra);
  const m = Math.floor((ra - h) * 60);
  const s = Math.round((((ra - h) * 60) - m) * 60);
  return `${h}h ${m}m ${s}s`;
}

function formatDec(dec: number): string {
  const sign = dec >= 0 ? '+' : '−';
  const abs = Math.abs(dec);
  const d = Math.floor(abs);
  const m = Math.floor((abs - d) * 60);
  const s = Math.round((((abs - d) * 60) - m) * 60);
  return `${sign}${d}° ${m}′ ${s}″`;
}

function brightnessLabel(mag: number): { label: string; color: string } {
  if (mag < 0) return { label: 'Dazzling', color: 'text-gold-300' };
  if (mag < 1) return { label: 'Very Bright', color: 'text-silver-100' };
  if (mag < 3) return { label: 'Bright', color: 'text-silver-200' };
  if (mag < 5) return { label: 'Faint', color: 'text-silver-400' };
  return { label: 'Very Faint', color: 'text-silver-500' };
}

export default function Dashboard({ objects, loading }: Props) {
  return (
    <div className="animate-fadeIn">
      <div className="flex flex-col gap-2 mb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-gold-500/80">
          Observation Log
        </p>
        <h2 className="font-display text-4xl font-semibold text-silver-100 text-glow-gold">
          Recorded Celestial Objects
        </h2>
        <p className="text-silver-400 text-sm max-w-2xl">
          A catalogue of stars and phenomena logged by the Nyx registry. Each
          entry captures its position in the sky and apparent brightness from
          Earth.
        </p>
      </div>

      {loading ? (
        <div className="glass-panel rounded-2xl p-16 text-center">
          <Telescope size={32} className="mx-auto text-gold-400 animate-drift mb-4" />
          <p className="text-silver-300">Scanning the heavens…</p>
        </div>
      ) : objects.length === 0 ? (
        <div className="glass-panel rounded-2xl p-16 text-center">
          <Compass size={32} className="mx-auto text-silver-400 mb-4" />
          <p className="text-silver-200 text-lg">No objects logged yet.</p>
          <p className="text-silver-400 text-sm mt-1">
            Add your first celestial object to begin the registry.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {objects.map((obj, idx) => {
            const bright = brightnessLabel(obj.apparent_magnitude);
            return (
              <article
                key={obj.id}
                className="glass-panel rounded-2xl p-5 hover:border-gold-500/30 transition-all duration-300 hover:-translate-y-1 group animate-fadeIn"
                style={{ animationDelay: `${idx * 60}ms` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="relative">
                      <Star
                        size={22}
                        className="text-gold-400 fill-gold-400/20 group-hover:fill-gold-400/40 transition-all duration-300"
                      />
                      <span className="absolute inset-0 blur-md bg-gold-500/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </span>
                    <div>
                      <h3 className="font-display text-xl text-silver-100 font-semibold leading-tight">
                        {obj.name}
                      </h3>
                      <p className="text-xs uppercase tracking-widest text-silver-400 mt-0.5">
                        {obj.constellation}
                      </p>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] uppercase tracking-wider px-2 py-1 rounded-full border border-silver-500/15 bg-ink-900/60 ${bright.color}`}
                  >
                    {bright.label}
                  </span>
                </div>

                <div className="space-y-2.5 text-sm">
                  <div className="flex items-center justify-between border-b border-silver-500/8 pb-2">
                    <span className="flex items-center gap-2 text-silver-400">
                      <Compass size={14} className="text-stellar-cyan/70" />
                      Right Ascension
                    </span>
                    <span className="font-mono text-xs text-silver-100">
                      {formatRA(obj.right_ascension)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-b border-silver-500/8 pb-2">
                    <span className="flex items-center gap-2 text-silver-400">
                      <Ruler size={14} className="text-stellar-cyan/70" />
                      Declination
                    </span>
                    <span className="font-mono text-xs text-silver-100">
                      {formatDec(obj.declination)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2 text-silver-400">
                      <Star size={14} className="text-gold-500/70" />
                      Apparent Magnitude
                    </span>
                    <span className="font-mono text-xs text-gold-300">
                      {obj.apparent_magnitude.toFixed(2)}
                    </span>
                  </div>
                </div>

                <p className="mt-4 pt-3 border-t border-silver-500/8 text-[10px] uppercase tracking-wider text-silver-500">
                  Logged {new Date(obj.discovered_at).toLocaleDateString(undefined, {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </p>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
