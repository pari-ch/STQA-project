import { useEffect, useState } from 'react';
import { Image as ImageIcon, Loader2, AlertTriangle } from 'lucide-react';
import { analyzeImage, type AnalysisResult } from '@/services/imageAnalysis';

type Props = {
  imageSrc: string;
};

export default function ImageAnalysisCard({ imageSrc }: Props) {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    analyzeImage(imageSrc)
      .then((r) => { if (!cancelled) { setResult(r); setLoading(false); } })
      .catch((e) => { if (!cancelled) { setError(e.message); setLoading(false); } });
    return () => { cancelled = true; };
  }, [imageSrc]);

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-starlight-400 py-4">
        <Loader2 size={16} className="animate-spin" />
        Analyzing image…
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center gap-2 text-sm text-amber-400 py-4">
        <AlertTriangle size={16} />
        {error}
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="space-y-3 animate-fadeIn">
      <div className="flex items-center gap-2 text-xs text-amber-400/80 bg-amber-400/5 border border-amber-400/15 rounded-lg px-3 py-2">
        <ImageIcon size={14} />
        Experimental basic analysis — not a scientific light-pollution measurement.
      </div>

      <div className="grid grid-cols-2 gap-3">
        <StatBox label="Image Size" value={`${result.width} × ${result.height}`} />
        <StatBox label="Avg Brightness" value={`${result.averageBrightness}%`} />
        <StatBox label="Dark Sky Pixels" value={`${result.darkPixelPercent}%`} accent="blue" />
        <StatBox label="Bright Regions" value={`${result.brightPixelPercent}%`} accent="cyan" />
      </div>

      <div>
        <div className="flex justify-between text-[10px] uppercase tracking-wider text-starlight-400 mb-1.5">
          <span>Brightness Distribution</span>
          <span>{result.averageBrightness}%</span>
        </div>
        <div className="h-2 rounded-full bg-sky-800/60 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-nebula-blue to-nebula-cyan transition-all duration-700"
            style={{ width: `${result.averageBrightness}%` }}
          />
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1">
        <span className="text-[10px] uppercase tracking-wider text-starlight-400">Avg Color</span>
        <div
          className="w-6 h-6 rounded border border-starlight-400/20"
          style={{ backgroundColor: `rgb(${result.averageRed}, ${result.averageGreen}, ${result.averageBlue})` }}
        />
        <span className="text-xs text-starlight-300 font-mono">
          rgb({result.averageRed}, {result.averageGreen}, {result.averageBlue})
        </span>
      </div>
    </div>
  );
}

function StatBox({ label, value, accent }: { label: string; value: string; accent?: 'blue' | 'cyan' }) {
  const color = accent === 'blue' ? 'text-nebula-blue' : accent === 'cyan' ? 'text-nebula-cyan' : 'text-starlight-100';
  return (
    <div className="rounded-lg bg-sky-900/50 border border-starlight-400/10 px-3 py-2.5">
      <p className="text-[10px] uppercase tracking-wider text-starlight-400">{label}</p>
      <p className={`text-base font-mono font-medium ${color}`}>{value}</p>
    </div>
  );
}
