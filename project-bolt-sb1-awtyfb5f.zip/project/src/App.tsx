import { useState, useEffect } from 'react';
import type { Page, Observation } from '@/types/observation';
import { useObservations } from '@/hooks/useObservations';
import Starfield from '@/components/Starfield';
import NavBar from '@/components/NavBar';
import HomePage from '@/pages/HomePage';
import CapturePage from '@/pages/CapturePage';
import SkyMapPage from '@/pages/SkyMapPage';
import SkyExplorerPage from '@/pages/SkyExplorerPage';
import DashboardPage from '@/pages/DashboardPage';
import AboutPage from '@/pages/AboutPage';

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [explorerFocusId, setExplorerFocusId] = useState<string | null>(null);
  const observations = useObservations();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [page]);

  const navigate = (p: Page) => {
    if (p !== 'explorer') setExplorerFocusId(null);
    setPage(p);
  };

  const viewInExplorer = (obs: Observation) => {
    setExplorerFocusId(obs.id);
  };

  return (
    <div className="min-h-screen relative">
      <Starfield />
      <div className="relative z-10">
        <NavBar current={page} onNavigate={navigate} />
        <main className="pb-20 lg:pb-8">
          {page === 'home' && <HomePage observations={observations} onNavigate={navigate} />}
          {page === 'capture' && <CapturePage onNavigate={navigate} />}
          {page === 'map' && <SkyMapPage observations={observations} />}
          {page === 'explorer' && <SkyExplorerPage observations={observations} focusId={explorerFocusId} />}
          {page === 'dashboard' && <DashboardPage observations={observations} />}
          {page === 'about' && <AboutPage onNavigate={navigate} />}
        </main>
        <footer className="hidden lg:block max-w-7xl mx-auto px-6 py-6 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-starlight-500">
            SkyTrace · Crowdsourced Sky Mapping · Prototype
          </p>
        </footer>
      </div>
    </div>
  );
}
