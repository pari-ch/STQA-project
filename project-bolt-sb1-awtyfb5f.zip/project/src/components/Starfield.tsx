export default function Starfield() {
  return <div className="starfield-bg" aria-hidden="true" />;
}
