import { Sparkles, Cpu, Cloud, Lightbulb, Satellite, Zap, Database, Users, Globe, ArrowRight } from 'lucide-react';
import type { Page } from '@/types/observation';
import GlassCard from '@/components/GlassCard';

type Props = {
  onNavigate: (page: Page) => void;
};

const FUTURE_FEATURES = [
  { icon: Sparkles, title: 'AI Star Detection', desc: 'Automatically identify stars, constellations, and deep-sky objects in uploaded photos.' },
  { icon: Cloud, title: 'Cloud Detection', desc: 'Classify sky conditions — clear, cloudy, partly cloudy — from image analysis.' },
  { icon: Lightbulb, title: 'Light Pollution Estimation', desc: 'Estimate Bortle scale and sky brightness from pixel analysis and location data.' },
  { icon: Zap, title: 'Meteor Detection', desc: 'Flag streaks and transient bright objects that may be meteors or satellites.' },
  { icon: Satellite, title: 'Satellite Detection', desc: 'Identify satellite trails and distinguish them from aircraft and meteors.' },
  { icon: Cpu, title: 'Celestial Coordinate Transform', desc: 'Convert azimuth/elevation to RA/Dec using accurate time and location transforms.' },
  { icon: Globe, title: 'Global Reconstruction', desc: 'Stitch observations from many users into a continuous sky atlas.' },
  { icon: Database, title: 'Cloud Backend', desc: 'Migrate from localStorage to Firebase or Supabase for real-time multi-user sync.' },
  { icon: Users, title: 'User Accounts', desc: 'Profiles, observation history, and collaboration features for contributors.' },
];

export default function AboutPage({ onNavigate }: Props) {
  return (
    <div className="animate-fadeIn px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <p className="text-xs uppercase tracking-[0.3em] text-nebula-blue mb-2">About SkyTrace</p>
          <h2 className="font-display text-3xl font-bold text-starlight-100">A Crowdsourced Sky-Observation Network</h2>
        </div>

        <GlassCard className="p-6 sm:p-8 mb-6">
          <p className="text-starlight-200 leading-relaxed text-lg">
            SkyTrace is a prototype for a crowdsourced sky-observation network. Instead of relying only on
            simulated astronomical maps, SkyTrace explores whether observations from ordinary smartphones
            can be geographically and directionally organized into a shared visual map of the sky.
          </p>
          <p className="text-starlight-300 leading-relaxed mt-4">
            Every photo captured with SkyTrace carries metadata — where on Earth it was taken, which
            direction the camera was pointing, and at what angle. By combining observations from many
            people around the world, we can begin to piece together a collective picture of the night sky
            that no single observer could capture alone.
          </p>
        </GlassCard>

        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle />
            <h3 className="font-display text-xl font-bold text-starlight-100">Current Limitations</h3>
          </div>
          <GlassCard className="p-5">
            <ul className="space-y-2 text-sm text-starlight-300">
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-1">•</span>
                The current prototype is <span className="text-amber-300">not scientifically calibrated</span> — coordinates and orientations are approximate.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-1">•</span>
                Data is stored locally in your browser (localStorage), not on a shared server. Observations are not yet synced across devices.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-1">•</span>
                The Sky Explorer uses a simple 2D projection, not a true 3D celestial sphere.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-1">•</span>
                Device orientation sensors vary in accuracy across browsers and devices.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-1">•</span>
                Image analysis is basic pixel-level analysis, not a trained ML model.
              </li>
            </ul>
          </GlassCard>
        </div>

        <div className="mb-6">
          <h3 className="font-display text-xl font-bold text-starlight-100 mb-4">Future Development Roadmap</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {FUTURE_FEATURES.map((f, i) => (
              <GlassCard key={i} hover className="p-5 animate-slideUp">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-sky-800/60 border border-starlight-400/10 mb-3">
                  <f.icon size={18} className="text-nebula-cyan" />
                </div>
                <h4 className="font-medium text-starlight-100 text-sm mb-1">{f.title}</h4>
                <p className="text-xs text-starlight-400 leading-relaxed">{f.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>

        <div className="text-center py-6">
          <button onClick={() => onNavigate('capture')} className="btn-primary">
            <ArrowRight size={18} />
            Start Capturing
          </button>
        </div>
      </div>
    </div>
  );
}

function AlertCircle() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}
