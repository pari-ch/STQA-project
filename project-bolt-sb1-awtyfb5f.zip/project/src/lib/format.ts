import type { Observation } from '@/types/observation';

export function formatCoord(value: number, type: 'lat' | 'lng'): string {
  const dir = type === 'lat' ? (value >= 0 ? 'N' : 'S') : (value >= 0 ? 'E' : 'W');
  return `${Math.abs(value).toFixed(4)}° ${dir}`;
}

export function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function azimuthToCompass(az: number): string {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  return dirs[Math.round(az / 45) % 8];
}

export function getContinent(lat: number, lng: number): string {
  if (lat >= 8 && lat <= 55 && lng >= 68 && lng <= 145) return 'Asia';
  if (lat >= 35 && lat <= 72 && lng >= -25 && lng <= 45) return 'Europe';
  if (lat >= -35 && lat <= 37 && lng >= -20 && lng <= 55) return 'Africa';
  if (lat >= 14 && lat <= 72 && lng >= -170 && lng <= -50) return 'North America';
  if (lat >= -57 && lat <= 13 && lng >= -82 && lng <= -34) return 'South America';
  if (lat <= -10 && lng >= 110 && lng <= 160) return 'Oceania';
  if (lat <= -60) return 'Antarctica';
  return 'Other';
}
