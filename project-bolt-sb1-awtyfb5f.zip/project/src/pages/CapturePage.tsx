import { useState, useRef, useCallback, useEffect } from 'react';
import { Camera, MapPin, Compass, Gauge, Calendar, Upload, Check, Loader2, AlertTriangle, Crosshair, Telescope, RotateCcw, FileText } from 'lucide-react';
import type { Page, ObservationInput } from '@/types/observation';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useDeviceOrientation } from '@/hooks/useDeviceOrientation';
import { add } from '@/services/observations';
import { azimuthToCompass } from '@/lib/format';
import GlassCard from '@/components/GlassCard';
import ImageAnalysisCard from '@/components/ImageAnalysisCard';

type Props = {
  onNavigate: (page: Page) => void;
};

type CaptureStep = 'capture' | 'confirm';

export default function CapturePage({ onNavigate }: Props) {
  const geo = useGeolocation();
  const orient = useDeviceOrientation();
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<CaptureStep>('capture');
  const [imageData, setImageData] = useState<string | null>(null);
  const [manualLat, setManualLat] = useState('');
  const [manualLng, setManualLng] = useState('');
  const [manualAz, setManualAz] = useState('');
  const [manualEl, setManualEl] = useState('');
  const [manualFov, setManualFov] = useState('60');
  const [description, setDescription] = useState('');
  const [timestamp, setTimestamp] = useState(() => new Date().toISOString().slice(0, 16));
  const [useManualCoord, setUseManualCoord] = useState(false);
  const [useManualDir, setUseManualDir] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      if (step === 'capture') setTimestamp(new Date().toISOString().slice(0, 16));
    }, 30000);
    return () => clearInterval(interval);
  }, [step]);

  const handleFile = useCallback((file: File) => {
    setCameraError(null);
    if (!file.type.startsWith('image/')) {
      setCameraError('Please select an image file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setImageData(reader.result as string);
    reader.onerror = () => setCameraError('Could not read the selected image.');
    reader.readAsDataURL(file);
  }, []);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const resetCapture = () => {
    setImageData(null);
    setStep('capture');
    setDescription('');
    setSubmitError(null);
  };

  const effectiveLat = useManualCoord ? parseFloat(manualLat) : geo.location?.latitude;
  const effectiveLng = useManualCoord ? parseFloat(manualLng) : geo.location?.longitude;
  const effectiveAz = useManualDir ? parseFloat(manualAz) : orient.data.azimuth;
  const effectiveEl = useManualDir ? parseFloat(manualEl) : orient.data.elevation;

  const canConfirm = imageData && (effectiveLat != null && !isNaN(effectiveLat)) && (effectiveLng != null && !isNaN(effectiveLng));

  const handleConfirm = () => {
    if (!canConfirm || !imageData) return;
    setStep('confirm');
  };

  const handleSubmit = async () => {
    if (!imageData || effectiveLat == null || effectiveLng == null) return;
    setSubmitting(true);
    setSubmitError(null);
    try {
      const obs: ObservationInput = {
        image: imageData,
        latitude: effectiveLat,
        longitude: effectiveLng,
        timestamp: new Date(timestamp).toISOString(),
        azimuth: effectiveAz != null && !isNaN(effectiveAz) ? effectiveAz : 0,
        elevation: effectiveEl != null && !isNaN(effectiveEl) ? effectiveEl : 0,
        fieldOfView: parseFloat(manualFov) || 60,
        description: description.trim(),
        source: 'real',
      };
      add(obs);
      setSubmitting(false);
      onNavigate('map');
    } catch {
      setSubmitting(false);
      setSubmitError('Failed to save observation. Please try again.');
    }
  };

  if (step === 'confirm') {
    return (
      <div className="animate-fadeIn max-w-2xl mx-auto px-4 py-8">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-emerald-400/15 border border-emerald-400/40 mb-3">
            <Check size={26} className="text-emerald-300" />
          </div>
          <h2 className="font-display text-2xl font-bold text-starlight-100">Observation Captured</h2>
          <p className="text-sm text-starlight-400 mt-1">Review and submit your sky observation.</p>
        </div>

        <GlassCard className="overflow-hidden">
          <div className="relative h-64">
            <img src={imageData!} alt="Captured sky" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-sky-950 to-transparent" />
          </div>
          <div className="p-6 space-y-4">
            <ConfirmRow icon={MapPin} label="Latitude" value={effectiveLat!.toFixed(4)} />
            <ConfirmRow icon={MapPin} label="Longitude" value={effectiveLng!.toFixed(4)} />
            <ConfirmRow icon={Compass} label="Direction" value={effectiveAz != null ? `${effectiveAz.toFixed(1)}° (${azimuthToCompass(effectiveAz)})` : 'Not recorded'} />
            <ConfirmRow icon={Gauge} label="Elevation" value={effectiveEl != null ? `${effectiveEl.toFixed(1)}°` : 'Not recorded'} />
            <ConfirmRow icon={Calendar} label="Timestamp" value={new Date(timestamp).toLocaleString()} />
            <ConfirmRow icon={Telescope} label="Field of View" value={`${manualFov}°`} />
            {description && <ConfirmRow icon={FileText} label="Description" value={description} />}

            <div className="border-t border-starlight-400/10 pt-4">
              <p className="text-xs uppercase tracking-wider text-nebula-cyan mb-3">Basic Sky Analysis</p>
              <ImageAnalysisCard imageSrc={imageData!} />
            </div>

            {submitError && (
              <div className="flex items-center gap-2 text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">
                <AlertTriangle size={14} />
                {submitError}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button onClick={handleSubmit} disabled={submitting} className="btn-primary flex-1">
                {submitting ? <><Loader2 size={18} className="animate-spin" /> Submitting…</> : <><Check size={18} /> Submit Observation</>}
              </button>
              <button onClick={resetCapture} className="btn-secondary">
                <RotateCcw size={16} /> Retake
              </button>
            </div>
          </div>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="animate-fadeIn max-w-3xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-nebula-blue mb-2">Guided Capture</p>
        <h2 className="font-display text-3xl font-bold text-starlight-100">Capture the Sky</h2>
        <p className="text-sm text-starlight-400 mt-2 max-w-xl mx-auto">
          Take or upload a photo of the sky. We'll record your location, direction, and time.
          If a sensor is unavailable, enter the details manually.
        </p>
      </div>

      <div className="space-y-5">
        {/* Photo Capture */}
        <GlassCard className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <Camera size={18} className="text-nebula-cyan" />
            <h3 className="font-medium text-starlight-100">1. Sky Photograph</h3>
          </div>
          {imageData ? (
            <div className="relative rounded-xl overflow-hidden border border-nebula-blue/20 group">
              <img src={imageData} alt="Selected sky" className="w-full max-h-72 object-cover" />
              <button onClick={() => setImageData(null)} className="absolute top-2 right-2 p-2 rounded-lg bg-sky-950/80 text-starlight-300 hover:text-white transition-colors">
                <RotateCcw size={16} />
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row gap-3">
                <button onClick={() => cameraRef.current?.click()} className="btn-primary flex-1">
                  <Camera size={18} /> Take Photo
                </button>
                <button onClick={() => fileRef.current?.click()} className="btn-secondary flex-1">
                  <Upload size={18} /> Upload Image
                </button>
              </div>
              <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={onFileChange} />
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onFileChange} />
              {cameraError && (
                <p className="text-xs text-amber-400 flex items-center gap-1.5">
                  <AlertTriangle size={12} /> {cameraError}
                </p>
              )}
              <p className="text-xs text-starlight-500">Use your camera or upload an existing sky photo.</p>
            </div>
          )}
        </GlassCard>

        {/* GPS */}
        <GlassCard className="p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <MapPin size={18} className="text-nebula-cyan" />
              <h3 className="font-medium text-starlight-100">2. GPS Location</h3>
            </div>
            <button
              onClick={() => setUseManualCoord(!useManualCoord)}
              className="text-xs text-starlight-400 hover:text-nebula-cyan transition-colors"
            >
              {useManualCoord ? 'Use GPS' : 'Enter manually'}
            </button>
          </div>

          {!useManualCoord ? (
            <div className="space-y-3">
              {geo.loading ? (
                <p className="text-sm text-starlight-400 flex items-center gap-2">
                  <Loader2 size={14} className="animate-spin" /> Acquiring satellite fix…
                </p>
              ) : geo.location ? (
                <div className="grid grid-cols-2 gap-3">
                  <CoordBox label="Latitude" value={geo.location.latitude.toFixed(4)} />
                  <CoordBox label="Longitude" value={geo.location.longitude.toFixed(4)} />
                </div>
              ) : (
                <div className="space-y-2">
                  <button onClick={geo.request} className="btn-secondary w-full">
                    <Crosshair size={16} /> Get My Location
                  </button>
                  {geo.error && <p className="text-xs text-amber-400 flex items-center gap-1.5"><AlertTriangle size={12} /> {geo.error}</p>}
                  {!geo.supported && <p className="text-xs text-amber-400">Geolocation not supported. Enter coordinates manually.</p>}
                </div>
              )}
              {geo.location && (
                <p className="text-xs text-starlight-500">Accuracy: ±{Math.round(geo.location.accuracy)}m</p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-text">Latitude</label>
                <input type="number" step="any" value={manualLat} onChange={(e) => setManualLat(e.target.value)} placeholder="e.g. 19.0760" className="input-field" />
              </div>
              <div>
                <label className="label-text">Longitude</label>
                <input type="number" step="any" value={manualLng} onChange={(e) => setManualLng(e.target.value)} placeholder="e.g. 72.8777" className="input-field" />
              </div>
            </div>
          )}
        </GlassCard>

        {/* Orientation */}
        <GlassCard className="p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Compass size={18} className="text-nebula-cyan" />
              <h3 className="font-medium text-starlight-100">3. Camera Direction & Orientation</h3>
            </div>
            <button
              onClick={() => setUseManualDir(!useManualDir)}
              className="text-xs text-starlight-400 hover:text-nebula-cyan transition-colors"
            >
              {useManualDir ? 'Use Sensor' : 'Enter manually'}
            </button>
          </div>

          {!useManualDir ? (
            <div className="space-y-3">
              {!orient.supported ? (
                <p className="text-xs text-amber-400">Compass unavailable — enter direction manually.</p>
              ) : (
                <>
                  <button onClick={orient.request} className="btn-secondary w-full" disabled={orient.loading}>
                    {orient.loading ? <><Loader2 size={16} className="animate-spin" /> Requesting…</> : <><Compass size={16} /> Enable Compass</>}
                  </button>
                  {orient.error && <p className="text-xs text-amber-400 flex items-center gap-1.5"><AlertTriangle size={12} /> {orient.error}</p>}
                  {orient.data.azimuth != null && (
                    <div className="grid grid-cols-2 gap-3">
                      <CoordBox label="Azimuth" value={`${orient.data.azimuth.toFixed(0)}° ${azimuthToCompass(orient.data.azimuth)}`} />
                      <CoordBox label="Elevation" value={orient.data.elevation != null ? `${orient.data.elevation.toFixed(0)}°` : 'N/A'} />
                    </div>
                  )}
                  {orient.data.azimuth == null && !orient.error && !orient.loading && (
                    <p className="text-xs text-starlight-500">Tap "Enable Compass" to read device orientation. If unavailable, switch to manual entry.</p>
                  )}
                </>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="label-text">Azimuth (°)</label>
                <input type="number" min={0} max={360} step="any" value={manualAz} onChange={(e) => setManualAz(e.target.value)} placeholder="0–360" className="input-field" />
              </div>
              <div>
                <label className="label-text">Elevation (°)</label>
                <input type="number" min={-90} max={90} step="any" value={manualEl} onChange={(e) => setManualEl(e.target.value)} placeholder="-90 to 90" className="input-field" />
              </div>
              <div>
                <label className="label-text">FOV (°)</label>
                <input type="number" min={1} max={180} step="any" value={manualFov} onChange={(e) => setManualFov(e.target.value)} className="input-field" />
              </div>
            </div>
          )}
        </GlassCard>

        {/* Timestamp */}
        <GlassCard className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <Calendar size={18} className="text-nebula-cyan" />
            <h3 className="font-medium text-starlight-100">4. Date & Time</h3>
          </div>
          <input type="datetime-local" value={timestamp} onChange={(e) => setTimestamp(e.target.value)} className="input-field" />
        </GlassCard>

        {/* Description */}
        <GlassCard className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <FileText size={18} className="text-nebula-cyan" />
            <h3 className="font-medium text-starlight-100">5. Description (optional)</h3>
          </div>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
            placeholder="What did you see? Any notable features?"
            className="input-field resize-none"
          />
        </GlassCard>

        {/* Capture button */}
        <button onClick={handleConfirm} disabled={!canConfirm} className="btn-primary w-full text-lg py-4">
          <Check size={20} /> Capture Observation
        </button>
        {!canConfirm && (
          <p className="text-center text-xs text-starlight-500">
            {!imageData ? 'Add a sky photograph to continue.' : 'Provide GPS coordinates to continue.'}
          </p>
        )}
      </div>
    </div>
  );
}

function CoordBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-sky-900/50 border border-starlight-400/10 px-3 py-2">
      <p className="text-[10px] uppercase tracking-wider text-starlight-400">{label}</p>
      <p className="text-sm font-mono text-starlight-100">{value}</p>
    </div>
  );
}

function ConfirmRow({ icon: Icon, label, value }: { icon: typeof MapPin; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-sky-800/60 border border-starlight-400/10 flex items-center justify-center">
        <Icon size={14} className="text-nebula-cyan" />
      </div>
      <div className="flex-1 min-w-0">
        <span className="text-[10px] uppercase tracking-wider text-starlight-400">{label}</span>
        <p className="text-sm text-starlight-100 font-mono break-words">{value}</p>
      </div>
    </div>
  );
}
