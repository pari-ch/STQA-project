import { Camera, Map, ArrowRight, Users, Globe, MapPin, Eye, Sparkles } from 'lucide-react';
import type { Page, Observation } from '@/types/observation';
import { getContinent } from '@/lib/format';
import GlassCard from '@/components/GlassCard';

type Props = {
  observations: Observation[];
  onNavigate: (page: Page) => void;
};

export default function HomePage({ observations, onNavigate }: Props) {
  const locations = new Set(observations.map((o) => `${o.latitude.toFixed(2)},${o.longitude.toFixed(2)}`));
  const countries = new Set(observations.map((o) => getContinent(o.latitude, o.longitude)));
  const skyArea = observations.reduce((sum, o) => sum + o.fieldOfView * o.fieldOfView, 0);

  const stats = [
    { label: 'Observations', value: observations.length, icon: Camera, color: 'text-nebula-blue' },
    { label: 'Locations', value: locations.size, icon: MapPin, color: 'text-nebula-cyan' },
    { label: 'Continents', value: countries.size, icon: Globe, color: 'text-nebula-purple' },
    { label: 'Sky Area', value: `${Math.round(skyArea)}°²`, icon: Eye, color: 'text-nebula-indigo' },
  ];

  return (
    <div className="animate-fadeIn">
      {/* Hero */}
      <section className="relative text-center py-16 sm:py-24 px-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-nebula-blue/30 bg-nebula-blue/5 text-xs uppercase tracking-[0.2em] text-nebula-cyan mb-6 animate-fadeIn">
          <Sparkles size={12} />
          Crowdsourced Sky Mapping
        </div>
        <h1 className="font-display text-4xl sm:text-6xl font-bold leading-tight max-w-4xl mx-auto">
          <span className="gradient-text">Help build a map of the sky.</span>
        </h1>
        <p className="text-starlight-300 text-lg max-w-2xl mx-auto mt-6 leading-relaxed">
          People around Earth are collectively mapping the sky. Capture a piece of the night sky
          from where you stand, and SkyTrace will place it into a shared, direction-aware visual atlas.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
          <button onClick={() => onNavigate('capture')} className="btn-primary w-full sm:w-auto">
            <Camera size={18} />
            Capture the Sky
          </button>
          <button onClick={() => onNavigate('map')} className="btn-secondary w-full sm:w-auto">
            <Map size={18} />
            Explore Sky Map
          </button>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-5xl mx-auto px-4 mb-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, i) => (
            <GlassCard key={i} hover className="p-5 text-center animate-slideUp" >
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-sky-800/60 border border-starlight-400/10 mb-3">
                <stat.icon size={18} className={stat.color} />
              </div>
              <p className="font-display text-3xl font-bold text-starlight-100">{stat.value}</p>
              <p className="text-xs uppercase tracking-wider text-starlight-400 mt-1">{stat.label}</p>
            </GlassCard>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="max-w-5xl mx-auto px-4 mb-16">
        <div className="text-center mb-10">
          <p className="text-xs uppercase tracking-[0.3em] text-nebula-blue mb-2">How It Works</p>
          <h2 className="font-display text-3xl font-bold text-starlight-100">From photos to a shared sky</h2>
        </div>
        <GlassCard className="p-6 sm:p-10">
          <div className="space-y-0">
            {[1, 2, 3].map((n) => (
              <div key={n}>
                <div className="flex items-center gap-4 py-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-nebula-blue/30 to-nebula-indigo/20 border border-nebula-blue/30 flex items-center justify-center font-display font-bold text-nebula-cyan">
                    {n}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-starlight-100">
                      User {n} → Photo + GPS + Orientation
                    </p>
                    <p className="text-xs text-starlight-400 mt-0.5">
                      Captures sky with coordinates, azimuth, and elevation
                    </p>
                  </div>
                </div>
                {n < 3 && <div className="ml-6 h-6 w-px bg-gradient-to-b from-nebula-blue/40 to-transparent" />}
              </div>
            ))}
            <div className="ml-6 h-6 w-px bg-gradient-to-b from-nebula-blue/40 to-nebula-purple/40" />
            <div className="flex items-center gap-4 py-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-nebula-purple/20 border border-nebula-purple/40 flex items-center justify-center">
                <Users size={20} className="text-nebula-purple" />
              </div>
              <div>
                <p className="text-sm font-medium text-starlight-100">SkyTrace Database</p>
                <p className="text-xs text-starlight-400 mt-0.5">All observations stored with full metadata</p>
              </div>
            </div>
            <div className="ml-6 h-6 w-px bg-gradient-to-b from-nebula-purple/40 to-nebula-cyan/40" />
            <div className="flex items-center gap-4 py-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-nebula-cyan/20 border border-nebula-cyan/40 flex items-center justify-center">
                <Globe size={20} className="text-nebula-cyan" />
              </div>
              <div>
                <p className="text-sm font-medium text-starlight-100">Common Sky Coordinate System</p>
                <p className="text-xs text-starlight-400 mt-0.5">Normalize by azimuth, elevation, and location</p>
              </div>
            </div>
            <div className="ml-6 h-6 w-px bg-gradient-to-b from-nebula-cyan/40 to-nebula-blue/40" />
            <div className="flex items-center gap-4 py-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-nebula-blue to-nebula-indigo flex items-center justify-center">
                <Eye size={20} className="text-white" />
              </div>
              <div>
                <p className="text-sm font-medium text-starlight-100">Prototype Sky Reconstruction</p>
                <p className="text-xs text-starlight-400 mt-0.5">A shared visual map built from everyone's photos</p>
              </div>
            </div>
          </div>
          <div className="mt-6 pt-6 border-t border-starlight-400/10 text-center">
            <button onClick={() => onNavigate('explorer')} className="inline-flex items-center gap-2 text-sm text-nebula-cyan hover:text-white transition-colors">
              See the Sky Explorer
              <ArrowRight size={14} />
            </button>
          </div>
        </GlassCard>
      </section>

      {/* Recent observations preview */}
      <section className="max-w-7xl mx-auto px-4 mb-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-bold text-starlight-100">Recent Observations</h2>
          <button onClick={() => onNavigate('map')} className="text-sm text-nebula-cyan hover:text-white transition-colors flex items-center gap-1">
            View all <ArrowRight size={14} />
          </button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {observations.slice(0, 6).map((obs) => (
            <button
              key={obs.id}
              onClick={() => onNavigate('map')}
              className="group relative aspect-square rounded-xl overflow-hidden border border-starlight-400/10 hover:border-nebula-blue/40 transition-all duration-300 hover:-translate-y-1"
            >
              <img src={obs.image} alt={obs.description} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-sky-950/90 to-transparent" />
              <div className="absolute bottom-2 left-2 right-2">
                <p className="text-[10px] uppercase tracking-wider text-starlight-200 truncate">
                  {obs.source === 'sample' ? 'Demo' : 'User'}
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
