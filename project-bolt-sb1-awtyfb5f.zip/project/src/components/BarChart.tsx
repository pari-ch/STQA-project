type BarData = { label: string; value: number };

type Props = {
  data: BarData[];
  color?: string;
  height?: number;
};

export default function BarChart({ data, color = '#3b82f6', height = 180 }: Props) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const barWidth = 100 / data.length;

  return (
    <div className="w-full" style={{ height }}>
      <div className="flex items-end justify-between h-full gap-2">
        {data.map((d, i) => {
          const pct = (d.value / max) * 100;
          return (
            <div key={i} className="flex-1 flex flex-col items-center justify-end h-full gap-1.5 group">
              <span className="text-xs font-mono text-starlight-300 opacity-0 group-hover:opacity-100 transition-opacity">
                {d.value}
              </span>
              <div className="w-full flex justify-center" style={{ height: '100%' }}>
                <div
                  className="w-full max-w-[40px] rounded-t-md transition-all duration-500 hover:opacity-80"
                  style={{
                    height: `${pct}%`,
                    background: `linear-gradient(180deg, ${color}, ${color}40)`,
                    minHeight: d.value > 0 ? '4px' : '0',
                  }}
                />
              </div>
              <span className="text-[10px] text-starlight-400 text-center truncate w-full">{d.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
