import { useEffect, useState } from 'react';
import type { Observation } from '@/types/observation';
import { getAll, subscribe } from '@/services/observations';

export function useObservations(): Observation[] {
  const [observations, setObservations] = useState<Observation[]>(() => getAll());

  useEffect(() => {
    const unsub = subscribe(() => setObservations(getAll()));
    setObservations(getAll());
    return unsub;
  }, []);

  return observations;
}
