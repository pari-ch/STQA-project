import { useState, useCallback, useEffect } from 'react';
import type { DeviceOrientation as DeviceOrientationData } from '@/types/observation';

type OrientationState = {
  data: DeviceOrientationData;
  loading: boolean;
  error: string | null;
  supported: boolean;
  needsPermission: boolean;
};

function absoluteAlpha(event: DeviceOrientationEvent): number | null {
  const webkitHeading = (event as any).webkitCompassHeading as number | undefined;
  if (event.absolute || (event.alpha != null && webkitHeading != null)) {
    if (typeof webkitHeading === 'number') {
      return webkitHeading;
    }
    if (event.alpha != null) return 360 - event.alpha;
  }
  if (event.alpha != null) return event.alpha;
  return null;
}

export function useDeviceOrientation() {
  const [state, setState] = useState<OrientationState>({
    data: { azimuth: null, elevation: null },
    loading: false,
    error: null,
    supported: typeof window !== 'undefined' && 'DeviceOrientationEvent' in window,
    needsPermission: false,
  });

  const handleEvent = useCallback((event: DeviceOrientationEvent) => {
    const azimuth = absoluteAlpha(event);
    const beta = event.beta;
    let elevation: number | null = null;
    if (beta != null) {
      elevation = Math.max(-90, Math.min(90, beta));
    }
    setState((s) => ({
      ...s,
      data: { azimuth, elevation },
      loading: false,
      error: null,
    }));
  }, []);

  const startListening = useCallback(() => {
    window.addEventListener('deviceorientation', handleEvent, true);
  }, [handleEvent]);

  const request = useCallback(async () => {
    const D = (window as any).DeviceOrientationEvent;
    if (!D) {
      setState((s) => ({ ...s, error: 'Device orientation not supported. Enter direction manually.', supported: false }));
      return;
    }
    if (typeof D.requestPermission === 'function') {
      setState((s) => ({ ...s, loading: true, needsPermission: true }));
      try {
        const result = await D.requestPermission();
        if (result === 'granted') {
          setState((s) => ({ ...s, loading: false, needsPermission: false }));
          startListening();
        } else {
          setState((s) => ({ ...s, loading: false, error: 'Orientation permission denied. Enter direction manually.' }));
        }
      } catch {
        setState((s) => ({ ...s, loading: false, error: 'Could not request orientation permission. Enter direction manually.' }));
      }
    } else {
      startListening();
    }
  }, [startListening]);

  useEffect(() => {
    return () => {
      window.removeEventListener('deviceorientation', handleEvent, true);
    };
  }, [handleEvent]);

  return { ...state, request };
}
